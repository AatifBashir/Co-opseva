// components/societydashboard.jsx
import React, { useState, useEffect } from 'react';
import {
  Alert,
  Modal,
  Pressable,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
  useWindowDimensions,
} from 'react-native';

const COLORS = {
  teal: '#7C6CA8',
  tealDark: '#5B4A8A',
  navy: '#3A2D59',
  bg: '#F3ECE0',
  white: '#FFFFFF',
  text: '#33284A',
  muted: '#736A8F',
  border: '#E4DDEF',
  lightPurple: '#EFEAF7',
  accent: '#7C6CA8',
  green: '#2E7D32',
  greenLight: '#E8F5E9',
  amber: '#D97706',
  amberLight: '#FEF3C7',
  red: '#DC2626',
  redLight: '#FEE2E2',
};

const SOCIETY_NAV = [
  {
    title: 'GOVERNANCE & VOTING',
    items: [
      ['overview', '▦', 'Dashboard'],
      ['rateFloors', '⚖', 'Rate-Floor Voting'],
      ['dispatches', '▣', 'FairShare Dispatches'],
    ],
  },
  {
    title: 'FINANCIAL & RESERVES',
    items: [
      ['escrow', '₹', 'Cooperative Escrow'],
      ['welfare', '♥', 'Welfare Ledger'],
    ],
  },
  {
    title: 'CAPACITY & COMPLIANCE',
    items: [
      ['forecasting', '📈', 'Demand Forecast'],
      ['workers', '⚒', 'Worker Roster & Certs'],
      ['disputes', '⚠', 'Dispute Resolution'],
    ],
  },
];

const FORECAST_DATA = [
  { trade: 'Electrical', demand: 'High (+24%)', capacity: 'Deficit (-3 Workers)', action: 'Fast-track onboard' },
  { trade: 'Plumbing', demand: 'Moderate (+8%)', capacity: 'Balanced', action: 'Normal' },
  { trade: 'Appliance Repair', demand: 'Surging (+38%)', capacity: 'Critical Deficit', action: 'Launch Skill Academy' },
  { trade: 'Cleaning / Pest', demand: 'Stable', capacity: 'Adequate', action: 'Maintain' },
];

export default function SocietyDashboard({
  navigation,
  societyName = 'Lucknow Central Labour Cooperative #14',
  adminName = 'Dr. S. K. Awasthi',
  onLogout,
}) {
  const { width } = useWindowDimensions();
  const isDesktop = width >= 992;
  const isTablet = width >= 768;

  const [activeTab, setActiveTab] = useState('overview');
  const [store, setStore] = useState(window.CoopStore ? window.CoopStore.get() : null);
  const [proposeModal, setProposeModal] = useState(false);
  const [newTrade, setNewTrade] = useState('');
  const [newRate, setNewRate] = useState('');

  useEffect(() => {
    if (window.CoopStore) {
      const unsub = window.CoopStore.subscribe((updated) => setStore(updated));
      return () => unsub();
    }
  }, []);

  const handleVote = (voteId, inFavor) => {
    if (window.CoopStore) {
      window.CoopStore.castRateVote(voteId, inFavor);
      Alert.alert('Vote Cast', `Democratic vote registered for proposal ${voteId}.`);
    }
  };

  const handleCreateVote = () => {
    if (!newTrade || !newRate) {
      Alert.alert('Incomplete', 'Please provide trade and proposed minimum rate.');
      return;
    }
    const current = window.CoopStore ? window.CoopStore.get() : null;
    if (current) {
      const voteObj = {
        id: `VOTE-${Date.now()}`,
        trade: newTrade,
        currentFloor: 300,
        proposedFloor: parseInt(newRate, 10),
        votesFor: 1,
        votesAgainst: 0,
        active: true,
      };
      current.rateFloorVotes.push(voteObj);
      window.CoopStore.set(current);
      setProposeModal(false);
      setNewTrade('');
      setNewRate('');
    }
  };

  const contentPadding = width >= 1200 ? 32 : width >= 768 ? 20 : 14;
  const rateVotes = store?.rateFloorVotes || [];
  const activeJobs = store?.jobs || [];

  return (
    <View style={styles.root}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.bg} />

      {/* Society Sidebar */}
      {isDesktop && (
        <View style={styles.sidebar}>
          <View style={styles.brand}>
            <View style={styles.logoMark}>
              <Text style={styles.logoMarkText}>♟</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.brandText}>
                <Text style={{ color: COLORS.teal }}>CO-OP</Text>
                <Text style={{ color: COLORS.tealDark }}>SEVA</Text>
              </Text>
              <Text style={styles.societyTag}>SOCIETY GOVERNANCE</Text>
            </View>
          </View>

          <ScrollView showsVerticalScrollIndicator={false}>
            {SOCIETY_NAV.map((group) => (
              <View key={group.title} style={{ marginBottom: 16 }}>
                <Text style={styles.navTitle}>{group.title}</Text>
                {group.items.map(([key, icon, label]) => (
                  <Pressable
                    key={key}
                    onPress={() => setActiveTab(key)}
                    style={[styles.sideLink, activeTab === key && styles.sideLinkActive]}
                  >
                    <Text style={[styles.sideIcon, activeTab === key && { color: COLORS.teal }]}>{icon}</Text>
                    <Text style={[styles.sideLinkText, activeTab === key && styles.sideLinkTextActive]}>
                      {label}
                    </Text>
                  </Pressable>
                ))}
              </View>
            ))}
          </ScrollView>

          <View style={styles.sidebarBottom}>
            <View style={styles.adminBadge}>
              <View style={styles.adminAvatar}>
                <Text style={styles.adminAvatarText}>SA</Text>
              </View>
              <View style={{ flex: 1, marginLeft: 9 }}>
                <Text style={styles.adminName} numberOfLines={1}>{adminName}</Text>
                <Text style={styles.adminRole}>Society General Secretary</Text>
              </View>
            </View>
            <Pressable onPress={onLogout} style={styles.logoutButton}>
              <Text style={styles.logoutText}>↪  Sign Out</Text>
            </Pressable>
          </View>
        </View>
      )}

      {/* Main Content Area */}
      <View style={[styles.main, isDesktop && { marginLeft: 260 }]}>
        <SafeAreaView style={{ flex: 1 }}>
          {/* Topbar */}
          <View style={[styles.topbar, { paddingHorizontal: contentPadding }]}>
            <View>
              <Text style={styles.topbarTitle}>Society Administrative Console</Text>
              <Text style={styles.topbarSubtitle}>{societyName}</Text>
            </View>
            <View style={styles.topbarRight}>
              <View style={styles.quorumPill}>
                <View style={styles.quorumDot} />
                <Text style={styles.quorumText}>Quorum Met: 84.6% Active</Text>
              </View>
              <Pressable
                onPress={() => {
                  if (navigation?.navigate) navigation.navigate('Panel');
                  else if (onLogout) onLogout();
                }}
                style={styles.switchPortalBtn}
              >
                <Text style={styles.switchPortalText}>Exit to Home</Text>
              </Pressable>
            </View>
          </View>

          <ScrollView contentContainerStyle={[styles.content, { paddingHorizontal: contentPadding }]}>
            {/* High Level Governance Metrics */}
            <View style={styles.statGrid}>
              <View style={styles.statCard}>
                <Text style={styles.statLabel}>COOPERATIVE RESERVE POOL</Text>
                <Text style={styles.statValue}>₹3,42,850</Text>
                <Text style={styles.statFoot}>10% operational margin balance</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statLabel}>MUTUAL WELFARE ESCROW</Text>
                <Text style={styles.statValue}>₹1,18,200</Text>
                <Text style={styles.statFoot}>Emergency medical & accident reserve</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statLabel}>CERTIFIED ACTIVE WORKERS</Text>
                <Text style={styles.statValue}>142</Text>
                <Text style={styles.statFoot}>98.2% valid certifications</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statLabel}>FAIRSHARE GINI INDEX</Text>
                <Text style={styles.statValue}>0.12</Text>
                <Text style={styles.statFoot}>Near-perfect income distribution</Text>
              </View>
            </View>

            {/* Rate-Floor Democratic Voting Section */}
            <View style={styles.sectionHeaderRow}>
              <View>
                <Text style={styles.sectionHeading}>Democratic Rate-Floor Voting™</Text>
                <Text style={styles.sectionSub}>
                  Cooperative members vote to enforce minimum legal living wages per trade.
                </Text>
              </View>
              <Pressable onPress={() => setProposeModal(true)} style={styles.proposeBtn}>
                <Text style={styles.proposeBtnText}>+ New Rate Proposal</Text>
              </Pressable>
            </View>

            <View style={isTablet ? styles.twoColumn : styles.oneColumn}>
              {rateVotes.map((vote) => {
                const total = vote.votesFor + vote.votesAgainst;
                const forPercent = total === 0 ? 0 : Math.round((vote.votesFor / total) * 100);

                return (
                  <View key={vote.id} style={styles.voteCard}>
                    <View style={styles.voteTop}>
                      <View>
                        <Text style={styles.voteTrade}>{vote.trade}</Text>
                        <Text style={styles.voteFloors}>
                          Current: ₹{vote.currentFloor} → Proposed: <Text style={{ color: COLORS.teal, fontWeight: '900' }}>₹{vote.proposedFloor}</Text>/hr
                        </Text>
                      </View>
                      <View style={styles.voteStatusBadge}>
                        <Text style={styles.voteStatusText}>{vote.active ? 'Voting Active' : 'Adopted'}</Text>
                      </View>
                    </View>

                    <View style={styles.voteProgressBar}>
                      <View style={[styles.voteProgressFill, { width: `${forPercent}%` }]} />
                    </View>

                    <View style={styles.voteMetaRow}>
                      <Text style={styles.voteMetaText}>Approval: {forPercent}% ({vote.votesFor} In Favor)</Text>
                      <Text style={styles.voteMetaText}>{vote.votesAgainst} Opposed</Text>
                    </View>

                    <View style={styles.voteBtnRow}>
                      <Pressable onPress={() => handleVote(vote.id, true)} style={styles.voteInFavorBtn}>
                        <Text style={styles.voteInFavorText}>✓ Vote In Favor</Text>
                      </Pressable>
                      <Pressable onPress={() => handleVote(vote.id, false)} style={styles.voteAgainstBtn}>
                        <Text style={styles.voteAgainstText}>× Vote Against</Text>
                      </Pressable>
                    </View>
                  </View>
                );
              })}
            </View>

            {/* Need-Before-Demand Capacity Forecaster */}
            <View style={[styles.sectionHeaderRow, { marginTop: 24 }]}>
              <View>
                <Text style={styles.sectionHeading}>Need Before Demand™ Capacity Forecast</Text>
                <Text style={styles.sectionSub}>
                  Predictive 3-day regional trade shortage analysis.
                </Text>
              </View>
            </View>

            <View style={styles.tablePanel}>
              <View style={styles.tableHeader}>
                <Text style={[styles.th, { flex: 1.2 }]}>TRADE</Text>
                <Text style={[styles.th, { flex: 1 }]}>PROJECTED DEMAND</Text>
                <Text style={[styles.th, { flex: 1.2 }]}>SOCIETY CAPACITY</Text>
                <Text style={[styles.th, { flex: 1.2 }]}>GOVERNANCE ACTION</Text>
              </View>

              {FORECAST_DATA.map((item) => (
                <View key={item.trade} style={styles.tableRow}>
                  <Text style={[styles.tdBold, { flex: 1.2 }]}>{item.trade}</Text>
                  <Text style={[styles.td, { flex: 1 }]}>{item.demand}</Text>
                  <Text style={[styles.td, { flex: 1.2, color: item.capacity.includes('Deficit') ? COLORS.amber : COLORS.text }]}>
                    {item.capacity}
                  </Text>
                  <View style={{ flex: 1.2 }}>
                    <Text style={styles.actionTag}>{item.action}</Text>
                  </View>
                </View>
              ))}
            </View>

            {/* Real-time FairShare Dispatch Queue */}
            <View style={[styles.sectionHeaderRow, { marginTop: 24 }]}>
              <View>
                <Text style={styles.sectionHeading}>Live Cooperative Dispatches</Text>
                <Text style={styles.sectionSub}>
                  Audit trail showing automatic FairShare™ assignments with tamper-evident margins.
                </Text>
              </View>
            </View>

            <View style={styles.tablePanel}>
              <View style={styles.tableHeader}>
                <Text style={[styles.th, { flex: 1 }]}>JOB ID</Text>
                <Text style={[styles.th, { flex: 1.5 }]}>CUSTOMER & PROBLEM</Text>
                <Text style={[styles.th, { flex: 1 }]}>ASSIGNED WORKER</Text>
                <Text style={[styles.th, { flex: 0.8 }]}>FEE</Text>
                <Text style={[styles.th, { flex: 0.8 }]}>WORKER CUT</Text>
                <Text style={[styles.th, { flex: 0.8 }]}>STATUS</Text>
              </View>

              {activeJobs.map((job) => (
                <View key={job.id} style={styles.tableRow}>
                  <Text style={[styles.tdBold, { flex: 1 }]}>{job.id}</Text>
                  <View style={{ flex: 1.5, paddingRight: 8 }}>
                    <Text style={styles.tdBold}>{job.customerName || 'Resident'}</Text>
                    <Text style={styles.tdSub} numberOfLines={1}>{job.problemText || job.skill}</Text>
                  </View>
                  <Text style={[styles.td, { flex: 1 }]}>{job.workerName || 'Auto-Allocating...'}</Text>
                  <Text style={[styles.td, { flex: 0.8 }]}>₹{job.grossFee}</Text>
                  <Text style={[styles.tdBold, { flex: 0.8, color: COLORS.green }]}>₹{job.workerPayout}</Text>
                  <View style={{ flex: 0.8 }}>
                    <View style={styles.statusBadge}>
                      <Text style={styles.statusText}>{job.status}</Text>
                    </View>
                  </View>
                </View>
              ))}
            </View>
          </ScrollView>
        </SafeAreaView>
      </View>

      {/* Propose New Floor Modal */}
      <Modal visible={proposeModal} transparent animationType="fade" onRequestClose={() => setProposeModal(false)}>
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Propose Minimum Living Wage</Text>
            <Text style={styles.modalSubtitle}>
              New wage floors require a minimum 60% affirmative member quorum to become legally binding for dispatches.
            </Text>

            <Text style={styles.inputLabel}>TRADE / SPECIALIZATION</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="e.g. Masonry, Carpentry, AC Maintenance"
              value={newTrade}
              onChangeText={setNewTrade}
            />

            <Text style={styles.inputLabel}>PROPOSED BASE FLOOR RATE (₹ / HOUR)</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="e.g. 400"
              keyboardType="number-pad"
              value={newRate}
              onChangeText={setNewRate}
            />

            <View style={styles.modalActions}>
              <Pressable onPress={() => setProposeModal(false)} style={styles.cancelBtn}>
                <Text style={styles.cancelBtnText}>Cancel</Text>
              </Pressable>
              <Pressable onPress={handleCreateVote} style={styles.submitVoteBtn}>
                <Text style={styles.submitVoteBtnText}>Submit to Ballot</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: COLORS.bg },
  main: { flex: 1 },
  sidebar: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 260,
    backgroundColor: COLORS.white,
    borderRightWidth: 1,
    borderRightColor: COLORS.border,
    paddingTop: 24,
    paddingHorizontal: 16,
    zIndex: 10,
  },
  brand: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingBottom: 22,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    marginBottom: 16,
  },
  logoMark: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: COLORS.navy,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  logoMarkText: { color: COLORS.white, fontSize: 20, fontWeight: '900' },
  brandText: { fontSize: 18, fontWeight: '900', letterSpacing: 0.2 },
  societyTag: { color: COLORS.teal, fontSize: 8, fontWeight: '900', letterSpacing: 1.2, marginTop: 2 },
  navTitle: {
    color: COLORS.muted,
    fontSize: 9,
    fontWeight: '900',
    letterSpacing: 1.2,
    marginBottom: 8,
    marginHorizontal: 10,
  },
  sideLink: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 10,
    marginVertical: 2,
  },
  sideLinkActive: {
    backgroundColor: COLORS.lightPurple,
    borderLeftWidth: 3,
    borderLeftColor: COLORS.teal,
  },
  sideIcon: { width: 22, fontSize: 14, color: COLORS.muted, marginRight: 8 },
  sideLinkText: { color: COLORS.text, fontSize: 12, fontWeight: '700' },
  sideLinkTextActive: { color: COLORS.teal, fontWeight: '900' },
  sidebarBottom: {
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
    paddingTop: 14,
    paddingBottom: 20,
  },
  adminBadge: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  adminAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: COLORS.lightPurple,
    alignItems: 'center',
    justifyContent: 'center',
  },
  adminAvatarText: { color: COLORS.teal, fontSize: 11, fontWeight: '900' },
  adminName: { color: COLORS.navy, fontSize: 11, fontWeight: '900' },
  adminRole: { color: COLORS.muted, fontSize: 9, marginTop: 1 },
  logoutButton: {
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 8,
    backgroundColor: COLORS.bg,
  },
  logoutText: { color: COLORS.teal, fontSize: 11, fontWeight: '800' },

  topbar: {
    height: 70,
    backgroundColor: 'rgba(255,255,255,0.95)',
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  topbarTitle: { color: COLORS.navy, fontSize: 18, fontWeight: '900' },
  topbarSubtitle: { color: COLORS.muted, fontSize: 11, marginTop: 2 },
  topbarRight: { flexDirection: 'row', alignItems: 'center' },
  quorumPill: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.greenLight,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 50,
    marginRight: 10,
  },
  quorumDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: COLORS.green, marginRight: 6 },
  quorumText: { color: COLORS.green, fontSize: 10, fontWeight: '800' },
  switchPortalBtn: {
    borderWidth: 1,
    borderColor: COLORS.border,
    backgroundColor: COLORS.white,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 8,
  },
  switchPortalText: { color: COLORS.navy, fontSize: 11, fontWeight: '800' },

  content: { paddingVertical: 24 },
  statGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: -6,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    minWidth: 180,
    marginHorizontal: 6,
    marginBottom: 10,
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 16,
    padding: 18,
  },
  statLabel: { color: COLORS.muted, fontSize: 9, fontWeight: '900', letterSpacing: 1 },
  statValue: { color: COLORS.navy, fontSize: 24, fontWeight: '900', marginVertical: 4 },
  statFoot: { color: COLORS.muted, fontSize: 9 },

  sectionHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  sectionHeading: { color: COLORS.navy, fontSize: 16, fontWeight: '900' },
  sectionSub: { color: COLORS.muted, fontSize: 11, marginTop: 2 },
  proposeBtn: {
    backgroundColor: COLORS.teal,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 10,
  },
  proposeBtnText: { color: COLORS.white, fontSize: 11, fontWeight: '900' },

  oneColumn: { width: '100%' },
  twoColumn: { flexDirection: 'row', flexWrap: 'wrap', marginHorizontal: -6 },
  voteCard: {
    flex: 1,
    minWidth: 320,
    marginHorizontal: 6,
    marginBottom: 12,
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 16,
    padding: 16,
  },
  voteTop: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 },
  voteTrade: { color: COLORS.navy, fontSize: 14, fontWeight: '900' },
  voteFloors: { color: COLORS.muted, fontSize: 11, marginTop: 3 },
  voteStatusBadge: {
    backgroundColor: COLORS.lightPurple,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  voteStatusText: { color: COLORS.teal, fontSize: 9, fontWeight: '900' },
  voteProgressBar: {
    height: 8,
    backgroundColor: '#EAE6F2',
    borderRadius: 4,
    overflow: 'hidden',
    marginVertical: 8,
  },
  voteProgressFill: { height: '100%', backgroundColor: COLORS.teal, borderRadius: 4 },
  voteMetaRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 14 },
  voteMetaText: { color: COLORS.muted, fontSize: 10, fontWeight: '700' },
  voteBtnRow: { flexDirection: 'row', gap: 8 },
  voteInFavorBtn: {
    flex: 1,
    backgroundColor: COLORS.lightPurple,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 8,
  },
  voteInFavorText: { color: COLORS.teal, fontSize: 11, fontWeight: '900' },
  voteAgainstBtn: {
    flex: 1,
    borderWidth: 1,
    borderColor: COLORS.border,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 8,
  },
  voteAgainstText: { color: COLORS.muted, fontSize: 11, fontWeight: '800' },

  tablePanel: {
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 20,
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#FAF8FD',
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    paddingVertical: 10,
    paddingHorizontal: 14,
  },
  th: { color: COLORS.muted, fontSize: 9, fontWeight: '900', letterSpacing: 0.8 },
  tableRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: COLORS.lightPurple,
    paddingVertical: 12,
    paddingHorizontal: 14,
  },
  tdBold: { color: COLORS.navy, fontSize: 11, fontWeight: '800' },
  tdSub: { color: COLORS.muted, fontSize: 10, marginTop: 2 },
  td: { color: COLORS.text, fontSize: 11 },
  actionTag: {
    color: COLORS.teal,
    fontSize: 10,
    fontWeight: '800',
    backgroundColor: COLORS.lightPurple,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    alignSelf: 'flex-start',
  },
  statusBadge: {
    backgroundColor: COLORS.lightPurple,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 5,
    alignSelf: 'flex-start',
  },
  statusText: { color: COLORS.teal, fontSize: 9, fontWeight: '800' },

  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(46,34,68,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  modalCard: {
    width: '100%',
    maxWidth: 460,
    backgroundColor: COLORS.white,
    borderRadius: 20,
    padding: 24,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  modalTitle: { color: COLORS.navy, fontSize: 18, fontWeight: '900' },
  modalSubtitle: { color: COLORS.muted, fontSize: 11, lineHeight: 16, marginVertical: 8 },
  inputLabel: { color: COLORS.navy, fontSize: 10, fontWeight: '800', marginTop: 12, marginBottom: 5 },
  modalInput: {
    height: 44,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 10,
    paddingHorizontal: 12,
    fontSize: 12,
    color: COLORS.text,
  },
  modalActions: { flexDirection: 'row', gap: 10, marginTop: 20 },
  cancelBtn: {
    flex: 1,
    borderWidth: 1,
    borderColor: COLORS.border,
    paddingVertical: 10,
    borderRadius: 10,
    alignItems: 'center',
  },
  cancelBtnText: { color: COLORS.muted, fontSize: 12, fontWeight: '800' },
  submitVoteBtn: {
    flex: 1,
    backgroundColor: COLORS.teal,
    paddingVertical: 10,
    borderRadius: 10,
    alignItems: 'center',
  },
  submitVoteBtnText: { color: COLORS.white, fontSize: 12, fontWeight: '900' },
});