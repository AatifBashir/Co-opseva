import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Animated,
  Easing,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
  useWindowDimensions,
  Alert,
} from 'react-native';

// CO-OPSEVA project theme — aligned with panel.jsx
export const COLORS = {
  teal: '#7C6CA8',
  tealDark: '#5B4A8A',
  navy: '#3A2D59',
  bg: '#F3ECE0',
  white: '#FFFFFF',
  text: '#33284A',
  muted: '#736A8F',
  border: '#E4DDEF',
  lightPurple: '#EFEAF7',
  back: '#3A2D59',
  back2: '#2E2244',
  accent: '#7C6CA8',
};

// Keep your existing project logo here.
// If your asset has a different location, change only this line.
const LOGO = require('../assets/logo.png');

const DEMO_OTP = '123456';

const FEATURES = [
  { icon: '✓', text: 'Secure & trusted platform' },
  { icon: '♧', text: 'Community-first ecosystem' },
  { icon: '⌘', text: 'Connected cooperative network' },
  { icon: '▣', text: 'Accessible on every device' },
];

function Logo({ onPress }) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel="CO-OPSEVA home"
      style={({ pressed }) => [styles.logoWrap, pressed && { opacity: 0.8 }]}
    >
      <View style={styles.logoIcon}>
        <Animated.Image source={LOGO} resizeMode="contain" style={styles.logoImage} />
      </View>
      <Text style={styles.logoText}>
        CO-OP<Text style={styles.logoSeva}>SEVA</Text>
      </Text>
    </Pressable>
  );
}

function BackgroundDecor() {
  const float1 = useRef(new Animated.Value(0)).current;
  const float2 = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const a = Animated.loop(
      Animated.sequence([
        Animated.timing(float1, { toValue: 1, duration: 8000, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
        Animated.timing(float1, { toValue: 0, duration: 8000, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
      ])
    );
    const b = Animated.loop(
      Animated.sequence([
        Animated.timing(float2, { toValue: 1, duration: 10000, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
        Animated.timing(float2, { toValue: 0, duration: 10000, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
      ])
    );
    a.start();
    b.start();
    return () => { a.stop(); b.stop(); };
  }, [float1, float2]);

  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      <Animated.View
        style={[
          styles.bgOrbOne,
          { transform: [{ translateX: float1.interpolate({ inputRange: [0, 1], outputRange: [0, 25] }) }, { translateY: float1.interpolate({ inputRange: [0, 1], outputRange: [0, -20] }) }] },
        ]}
      />
      <Animated.View
        style={[
          styles.bgOrbTwo,
          { transform: [{ translateX: float2.interpolate({ inputRange: [0, 1], outputRange: [0, -20] }) }, { translateY: float2.interpolate({ inputRange: [0, 1], outputRange: [0, 25] }) }] },
        ]}
      />
    </View>
  );
}

function Icon({ name, size = 18, color = COLORS.teal, style }) {
  const glyphs = {
    home: '⌂',
    mail: '✉',
    lock: '▣',
    eye: '◉',
    eyeOff: '◌',
    arrow: '→',
    shield: '◆',
    people: '♧',
    network: '⌘',
    phone: '▯',
    check: '✓',
    back: '‹',
    close: '×',
  };
  return <Text style={[{ color, fontSize: size, fontWeight: '800' }, style]}>{glyphs[name] || '•'}</Text>;
}

function AnimatedLoginCard({ children }) {
  const opacity = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(25)).current;
  const scale = useRef(new Animated.Value(0.96)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(opacity, { toValue: 1, duration: 650, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
      Animated.spring(translateY, { toValue: 0, friction: 8, tension: 55, useNativeDriver: true }),
      Animated.spring(scale, { toValue: 1, friction: 8, tension: 55, useNativeDriver: true }),
    ]).start();
  }, [opacity, translateY, scale]);

  return <Animated.View style={[styles.loginCard, { opacity, transform: [{ translateY }, { scale }] }]}>{children}</Animated.View>;
}

function LeftPanel({ compact }) {
  const iconY = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(iconY, { toValue: -9, duration: 1500, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
        Animated.timing(iconY, { toValue: 0, duration: 1500, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [iconY]);

  return (
    <View style={[styles.leftPanel, compact && styles.leftPanelCompact]}>
      <View style={styles.leftRingLarge} />
      <View style={styles.leftRingSmall} />
      <Animated.View style={[styles.roleIcon, { transform: [{ translateY: iconY }] }]}>
        <Icon name="home" size={46} color="#D9C9F0" />
      </Animated.View>

      <Text style={styles.customerLabel}>CUSTOMER</Text>

      <Text style={styles.leftTitle}>
        Your cooperative{`\n`}
        <Text style={styles.leftTitleAccent}>journey starts here.</Text>
      </Text>

      <Text style={styles.leftDescription}>
        Connect with trusted household and community services through the CO-OPSEVA cooperative ecosystem.
      </Text>

      <View style={styles.features}>
        {FEATURES.map((feature, index) => (
          <View key={feature.text} style={styles.feature}>
            <Icon
              name={index === 0 ? 'check' : index === 1 ? 'people' : index === 2 ? 'network' : 'phone'}
              size={18}
              color="#C7B3E5"
            />
            <Text style={styles.featureText}>{feature.text}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

function Field({ label, icon, value, onChangeText, placeholder, secureTextEntry, onToggleSecure, keyboardType, autoCapitalize = 'none' }) {
  const [focused, setFocused] = useState(false);

  return (
    <View style={styles.fieldBlock}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <View style={[styles.inputBox, focused && styles.inputBoxFocused]}>
        <Icon name={icon} size={17} color={COLORS.teal} style={styles.inputIcon} />
        <TextInput
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor="#9A91AA"
          secureTextEntry={secureTextEntry}
          keyboardType={keyboardType}
          autoCapitalize={autoCapitalize}
          autoCorrect={false}
          style={styles.input}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
        />
        {onToggleSecure ? (
          <Pressable onPress={onToggleSecure} style={styles.passwordButton} accessibilityRole="button" accessibilityLabel="Show or hide password">
            <Icon name={secureTextEntry ? 'eye' : 'eyeOff'} size={18} color={COLORS.muted} />
          </Pressable>
        ) : null}
      </View>
    </View>
  );
}

function OTPModal({ visible, email, onClose, onVerified }) {
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [status, setStatus] = useState('Verification code required.');
  const [statusType, setStatusType] = useState('normal');
  const [verifying, setVerifying] = useState(false);
  const [verified, setVerified] = useState(false);
  const inputs = useRef([]);

  useEffect(() => {
    if (visible) {
      setOtp(['', '', '', '', '', '']);
      setStatus(email ? `A verification code has been sent to ${email}` : 'Verification code required.');
      setStatusType('normal');
      setVerifying(false);
      setVerified(false);
      setTimeout(() => inputs.current[0]?.focus(), 250);
    }
  }, [visible, email]);

  const updateDigit = (index, text) => {
    const digit = text.replace(/\D/g, '').slice(-1);
    const next = [...otp];
    next[index] = digit;
    setOtp(next);
    if (digit && index < 5) inputs.current[index + 1]?.focus();
  };

  const handleKeyPress = (index, key) => {
    if (key === 'Backspace' && !otp[index] && index > 0) {
      inputs.current[index - 1]?.focus();
    }
  };

  const verify = () => {
    const entered = otp.join('');
    if (entered.length !== 6) {
      setStatus('Please enter all 6 digits.');
      setStatusType('error');
      return;
    }
    if (entered !== DEMO_OTP) {
      setStatus('Incorrect OTP. Please try again.');
      setStatusType('error');
      return;
    }

    setVerifying(true);
    setStatusType('success');
    setTimeout(() => {
      setVerifying(false);
      setVerified(true);
      setStatus('OTP verified successfully. Redirecting to your dashboard...');
      setTimeout(() => onVerified?.(), 500);
    }, 700);
  };

  const resend = () => {
    setOtp(['', '', '', '', '', '']);
    setStatus('A new verification code has been sent.');
    setStatusType('success');
    setTimeout(() => inputs.current[0]?.focus(), 100);
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.modalKeyboard}>
          <View style={styles.otpCard}>
            <View style={styles.otpDecor} />
            <View style={styles.otpIcon}>
              <Icon name="shield" size={28} color={COLORS.white} />
            </View>
            <Text style={styles.otpTitle}>Verify Your Login</Text>
            <Text style={styles.otpDescription}>
              Enter the 6-digit verification code sent to your registered email/mobile.
            </Text>

            <View style={styles.otpInputs}>
              {otp.map((digit, index) => (
                <TextInput
                  key={index}
                  ref={(ref) => { inputs.current[index] = ref; }}
                  value={digit}
                  onChangeText={(text) => updateDigit(index, text)}
                  onKeyPress={({ nativeEvent }) => handleKeyPress(index, nativeEvent.key)}
                  maxLength={1}
                  keyboardType="number-pad"
                  textContentType="oneTimeCode"
                  selectTextOnFocus
                  style={styles.otpInput}
                  placeholder=""
                  placeholderTextColor={COLORS.muted}
                />
              ))}
            </View>

            <Text style={[styles.otpStatus, statusType === 'error' && styles.otpError, statusType === 'success' && styles.otpSuccess]}>
              {status}
            </Text>

            <View style={styles.otpActions}>
              <Pressable onPress={onClose} disabled={verifying} style={({ pressed }) => [styles.otpCancel, pressed && { opacity: 0.75 }]}>
                <Text style={styles.otpCancelText}>Cancel</Text>
              </Pressable>
              <Pressable onPress={verify} disabled={verifying || verified} style={({ pressed }) => [styles.otpVerify, pressed && { transform: [{ scale: 0.98 }] }, (verifying || verified) && styles.disabledButton]}>
                {verifying ? <ActivityIndicator size="small" color={COLORS.white} /> : <Text style={styles.otpVerifyText}>{verified ? '✓ Verified' : 'Verify OTP'}</Text>}
              </Pressable>
            </View>

            <Pressable onPress={resend} disabled={verifying} style={styles.resendButton}>
              <Text style={styles.resendText}>Resend OTP</Text>
            </Pressable>

            <View style={styles.otpDemo}>
              <Text style={styles.otpDemoText}>
                Frontend demo OTP: <Text style={styles.otpDemoStrong}>{DEMO_OTP}</Text>{`\n`}
                Replace this demo logic with your real OTP API/backend.
              </Text>
            </View>

            <Pressable onPress={onClose} style={styles.modalClose} accessibilityLabel="Close OTP modal">
              <Icon name="close" size={25} color={COLORS.muted} />
            </Pressable>
          </View>
        </KeyboardAvoidingView>
      </View>
    </Modal>
  );
}

export default function CustomerLoginNew({ navigation, onNavigate, onLoginSuccess, onRegister, onBack }) {
  const { width } = useWindowDimensions();
  const isWide = width >= 992;
  const isSmall = width <= 480;

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [otpVisible, setOtpVisible] = useState(false);
  const [loading, setLoading] = useState(false);

  const go = (route, callback) => {
    if (callback) {
      callback();
      return;
    }
    if (onNavigate) {
      onNavigate(route);
      return;
    }
    if (navigation?.navigate) {
      navigation.navigate(route);
      return;
    }
    Alert.alert('Navigation', `${route} screen is not connected yet.`);
  };

  const handleBack = () => {
    if (onBack) return onBack();
    if (navigation?.goBack) return navigation.goBack();
    go('Panel');
  };

  const handleSubmit = () => {
    if (!email.trim()) {
      Alert.alert('Email required', 'Please enter your email address.');
      return;
    }
    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
    if (!emailOk) {
      Alert.alert('Invalid email', 'Please enter a valid email address.');
      return;
    }
    if (!password) {
      Alert.alert('Password required', 'Please enter your password.');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setOtpVisible(true);
    }, 350);
  };

  const handleVerified = () => {
    setOtpVisible(false);
    onLoginSuccess?.({ email: email.trim(), remember });
    if (!onLoginSuccess) go('CustomerDashboard');
  };

  const handleForgot = () => {
    Alert.alert('Forgot password?', 'Password recovery can be connected to your backend/API here.');
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.bg} />
      <View style={styles.screen}>
        <BackgroundDecor />

        <View style={styles.navbar}>
          <View style={[styles.navbarInner, isSmall && styles.navbarInnerSmall]}>
            <Logo onPress={() => go('Panel')} />
            <Pressable onPress={handleBack} style={({ pressed }) => [styles.backLink, pressed && { opacity: 0.65 }]}>
              <Icon name="back" size={25} color={COLORS.muted} />
              {!isSmall && <Text style={styles.backText}>Back to Role Selection</Text>}
            </Pressable>
          </View>
        </View>

        <ScrollView
          contentContainerStyle={[styles.scrollContent, !isWide && styles.scrollContentTablet]}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={[styles.loginArea, isWide && styles.loginAreaWide]}>
            <AnimatedLoginCard>
              <View style={[styles.cardRow, !isWide && styles.cardStack]}>
                <View style={[styles.leftColumn, isWide ? styles.columnHalf : styles.columnFull]}>
                  <LeftPanel compact={!isWide} />
                </View>

                <View style={[styles.formColumn, isWide ? styles.columnHalf : styles.columnFull]}>
                  <View style={[styles.formPanel, isSmall && styles.formPanelSmall]}>
                    <View style={styles.formContent}>
                      <View style={styles.roleBadge}>
                        <Icon name="home" size={13} color={COLORS.teal} />
                        <Text style={styles.roleBadgeText}>CUSTOMER</Text>
                      </View>

                      <Text style={styles.formTitle}>Welcome Back</Text>
                      <Text style={styles.formDescription}>
                        Sign in to continue to your CO-OPSEVA customer workspace.
                      </Text>

                      <Field
                        label="EMAIL ADDRESS"
                        icon="mail"
                        value={email}
                        onChangeText={setEmail}
                        placeholder="you@example.com"
                        keyboardType="email-address"
                      />

                      <Field
                        label="PASSWORD"
                        icon="lock"
                        value={password}
                        onChangeText={setPassword}
                        placeholder="Enter your password"
                        secureTextEntry={!showPassword}
                        onToggleSecure={() => setShowPassword((v) => !v)}
                      />

                      <View style={styles.optionsRow}>
                        <Pressable onPress={() => setRemember((v) => !v)} style={styles.rememberRow} accessibilityRole="checkbox" accessibilityState={{ checked: remember }}>
                          <View style={[styles.checkbox, remember && styles.checkboxChecked]}>
                            {remember && <Text style={styles.checkboxTick}>✓</Text>}
                          </View>
                          <Text style={styles.rememberText}>Remember me</Text>
                        </Pressable>
                        <Pressable onPress={handleForgot}>
                          <Text style={styles.forgotText}>Forgot password?</Text>
                        </Pressable>
                      </View>

                      <Pressable onPress={handleSubmit} disabled={loading} style={({ pressed }) => [styles.loginButton, pressed && styles.loginButtonPressed, loading && styles.disabledButton]}>
                        {loading ? <ActivityIndicator size="small" color={COLORS.white} /> : (
                          <View style={styles.loginButtonInner}>
                            <Text style={styles.loginButtonText}>Login as Customer</Text>
                            <Icon name="arrow" size={20} color={COLORS.white} />
                          </View>
                        )}
                      </Pressable>

                      <View style={styles.divider}>
                        <View style={styles.dividerLine} />
                        <Text style={styles.dividerText}>SECURE COOPERATIVE ACCESS</Text>
                        <View style={styles.dividerLine} />
                      </View>

                      <View style={styles.registerTextRow}>
                        <Text style={styles.registerMuted}>Don't have an account? </Text>
                        <Pressable onPress={() => go('CustomerRegister', onRegister)}>
                          <Text style={styles.registerLink}>Register</Text>
                        </Pressable>
                      </View>

                      <View style={styles.securityBox}>
                        <Icon name="shield" size={17} color={COLORS.teal} />
                        <Text style={styles.securityText}>
                          Your information is protected with secure, role-based access.
                        </Text>
                      </View>
                    </View>
                  </View>
                </View>
              </View>
            </AnimatedLoginCard>
          </View>
        </ScrollView>

        <OTPModal
          visible={otpVisible}
          email={email.trim()}
          onClose={() => setOtpVisible(false)}
          onVerified={handleVerified}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.bg,
  },
  screen: {
    flex: 1,
    backgroundColor: COLORS.bg,
  },
  bgOrbOne: {
    position: 'absolute',
    width: 280,
    height: 280,
    borderRadius: 140,
    backgroundColor: 'rgba(124,108,168,0.08)',
    top: '7%',
    left: -105,
  },
  bgOrbTwo: {
    position: 'absolute',
    width: 240,
    height: 240,
    borderRadius: 120,
    backgroundColor: 'rgba(199,166,232,0.11)',
    right: -90,
    bottom: '9%',
  },
  navbar: {
    backgroundColor: 'rgba(255,255,255,0.94)',
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    zIndex: 10,
    elevation: 3,
  },
  navbarInner: {
    width: '100%',
    maxWidth: 1120,
    minHeight: 72,
    alignSelf: 'center',
    paddingHorizontal: 22,
    paddingVertical: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  navbarInnerSmall: {
    minHeight: 64,
    paddingHorizontal: 16,
  },
  logoWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
  },
  logoIcon: {
    width: 42,
    height: 42,
    borderRadius: 12,
    padding: 4,
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.border,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: COLORS.navy,
    shadowOpacity: 0.12,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 5 },
  },
  logoImage: {
    width: '100%',
    height: '100%',
  },
  logoText: {
    color: COLORS.navy,
    fontSize: 21,
    fontWeight: '900',
    letterSpacing: -0.4,
  },
  logoSeva: {
    color: COLORS.teal,
  },
  backLink: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingVertical: 8,
    paddingLeft: 8,
  },
  backText: {
    color: COLORS.muted,
    fontSize: 13,
    fontWeight: '700',
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 18,
    paddingVertical: 38,
  },
  scrollContentTablet: {
    paddingVertical: 24,
  },
  loginArea: {
    width: '100%',
    maxWidth: 1120,
    alignSelf: 'center',
    justifyContent: 'center',
  },
  loginAreaWide: {
    flex: 1,
  },
  loginCard: {
    width: '100%',
    backgroundColor: 'rgba(255,255,255,0.96)',
    borderRadius: 28,
    borderWidth: 1,
    borderColor: COLORS.border,
    overflow: 'hidden',
    shadowColor: COLORS.navy,
    shadowOpacity: 0.12,
    shadowRadius: 32,
    shadowOffset: { width: 0, height: 18 },
    elevation: 8,
  },
  cardRow: {
    flexDirection: 'row',
    minHeight: 620,
  },
  cardStack: {
    flexDirection: 'column',
    minHeight: 0,
  },
  leftColumn: {
    overflow: 'hidden',
  },
  formColumn: {
    backgroundColor: COLORS.white,
  },
  columnHalf: {
    width: '50%',
  },
  columnFull: {
    width: '100%',
  },
  leftPanel: {
    flex: 1,
    minHeight: 620,
    paddingHorizontal: 54,
    paddingVertical: 56,
    backgroundColor: COLORS.navy,
    overflow: 'hidden',
    justifyContent: 'center',
  },
  leftPanelCompact: {
    minHeight: 430,
    paddingHorizontal: 40,
    paddingVertical: 42,
  },
  leftRingLarge: {
    position: 'absolute',
    width: 350,
    height: 350,
    borderRadius: 175,
    right: -170,
    bottom: -170,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },
  leftRingSmall: {
    position: 'absolute',
    width: 180,
    height: 180,
    borderRadius: 90,
    left: -70,
    top: -65,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  roleIcon: {
    width: 100,
    height: 100,
    borderRadius: 28,
    backgroundColor: 'rgba(255,255,255,0.10)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
    shadowColor: '#000',
    shadowOpacity: 0.12,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 12 },
  },
  customerLabel: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 1.4,
    marginBottom: 10,
  },
  leftTitle: {
    color: COLORS.white,
    fontSize: 40,
    lineHeight: 44,
    fontWeight: '900',
    letterSpacing: -1.1,
    marginBottom: 18,
  },
  leftTitleAccent: {
    color: '#C7B3E5',
  },
  leftDescription: {
    color: 'rgba(255,255,255,0.72)',
    fontSize: 14,
    lineHeight: 25,
    maxWidth: 450,
    marginBottom: 20,
  },
  features: {
    gap: 4,
  },
  feature: {
    minHeight: 44,
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 11,
  },
  featureText: {
    color: 'rgba(255,255,255,0.84)',
    fontSize: 12,
    fontWeight: '600',
    flex: 1,
  },
  formPanel: {
    flex: 1,
    minHeight: 620,
    paddingHorizontal: 52,
    paddingVertical: 56,
    justifyContent: 'center',
  },
  formPanelSmall: {
    paddingHorizontal: 20,
    paddingVertical: 30,
  },
  formContent: {
    width: '100%',
    maxWidth: 470,
    alignSelf: 'center',
  },
  roleBadge: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 50,
    backgroundColor: COLORS.lightPurple,
    marginBottom: 16,
  },
  roleBadgeText: {
    color: COLORS.teal,
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 1.1,
  },
  formTitle: {
    color: COLORS.navy,
    fontSize: 32,
    lineHeight: 38,
    fontWeight: '900',
    letterSpacing: -0.7,
    marginBottom: 8,
  },
  formDescription: {
    color: COLORS.muted,
    fontSize: 13,
    lineHeight: 21,
    marginBottom: 24,
  },
  fieldBlock: {
    marginBottom: 15,
  },
  fieldLabel: {
    color: COLORS.navy,
    fontSize: 11,
    fontWeight: '800',
    marginBottom: 7,
    letterSpacing: 0.2,
  },
  inputBox: {
    height: 52,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
    backgroundColor: COLORS.white,
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: 14,
    paddingRight: 7,
  },
  inputBoxFocused: {
    borderColor: COLORS.teal,
    shadowColor: COLORS.teal,
    shadowOpacity: 0.10,
    shadowRadius: 0,
    elevation: 2,
    transform: [{ translateY: -1 }],
  },
  inputIcon: {
    width: 25,
    textAlign: 'center',
    marginRight: 4,
  },
  input: {
    flex: 1,
    height: '100%',
    color: COLORS.text,
    fontSize: 13,
    paddingVertical: 0,
  },
  passwordButton: {
    width: 39,
    height: 39,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
  },
  optionsRow: {
    minHeight: 34,
    marginTop: 2,
    marginBottom: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 14,
  },
  rememberRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  checkbox: {
    width: 18,
    height: 18,
    borderRadius: 4,
    borderWidth: 1.5,
    borderColor: COLORS.border,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.white,
  },
  checkboxChecked: {
    backgroundColor: COLORS.teal,
    borderColor: COLORS.teal,
  },
  checkboxTick: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: '900',
    lineHeight: 14,
  },
  rememberText: {
    color: COLORS.muted,
    fontSize: 11,
  },
  forgotText: {
    color: COLORS.teal,
    fontSize: 11,
    fontWeight: '800',
  },
  loginButton: {
    minHeight: 54,
    borderRadius: 12,
    backgroundColor: COLORS.teal,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: COLORS.teal,
    shadowOpacity: 0.24,
    shadowRadius: 15,
    shadowOffset: { width: 0, height: 9 },
    elevation: 5,
  },
  loginButtonPressed: {
    backgroundColor: COLORS.tealDark,
    transform: [{ translateY: 1 }, { scale: 0.99 }],
  },
  loginButtonInner: {
    width: '100%',
    paddingHorizontal: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  loginButtonText: {
    color: COLORS.white,
    fontSize: 13,
    fontWeight: '800',
  },
  disabledButton: {
    opacity: 0.75,
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginVertical: 22,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: COLORS.border,
  },
  dividerText: {
    color: '#9A91AA',
    fontSize: 8.5,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  registerTextRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    flexWrap: 'wrap',
  },
  registerMuted: {
    color: COLORS.muted,
    fontSize: 12,
  },
  registerLink: {
    color: COLORS.teal,
    fontSize: 12,
    fontWeight: '800',
  },
  securityBox: {
    marginTop: 20,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
    backgroundColor: '#FAF8FD',
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 9,
  },
  securityText: {
    flex: 1,
    color: COLORS.muted,
    fontSize: 10,
    lineHeight: 16,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(46,34,68,0.62)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  modalKeyboard: {
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  otpCard: {
    width: '100%',
    maxWidth: 440,
    borderRadius: 24,
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.border,
    padding: 30,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOpacity: 0.24,
    shadowRadius: 40,
    shadowOffset: { width: 0, height: 20 },
    elevation: 15,
  },
  otpDecor: {
    position: 'absolute',
    width: 180,
    height: 180,
    borderRadius: 90,
    right: -90,
    top: -90,
    backgroundColor: 'rgba(124,108,168,0.08)',
  },
  otpIcon: {
    width: 62,
    height: 62,
    borderRadius: 18,
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.teal,
    marginBottom: 15,
  },
  otpTitle: {
    color: COLORS.navy,
    fontSize: 22,
    lineHeight: 27,
    fontWeight: '900',
    textAlign: 'center',
    marginBottom: 6,
  },
  otpDescription: {
    color: COLORS.muted,
    fontSize: 12,
    lineHeight: 19,
    textAlign: 'center',
  },
  otpInputs: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
    marginVertical: 20,
  },
  otpInput: {
    width: 46,
    height: 52,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: COLORS.border,
    color: COLORS.navy,
    backgroundColor: COLORS.white,
    fontSize: 20,
    fontWeight: '800',
    textAlign: 'center',
  },
  otpStatus: {
    minHeight: 34,
    color: '#8C7E60',
    fontSize: 11,
    lineHeight: 17,
    fontWeight: '700',
    textAlign: 'center',
  },
  otpError: {
    color: '#B45309',
  },
  otpSuccess: {
    color: COLORS.teal,
  },
  otpActions: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 5,
  },
  otpCancel: {
    flex: 1,
    minHeight: 45,
    borderRadius: 11,
    borderWidth: 1,
    borderColor: COLORS.border,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.white,
  },
  otpCancelText: {
    color: COLORS.muted,
    fontSize: 12,
    fontWeight: '800',
  },
  otpVerify: {
    flex: 1,
    minHeight: 45,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.teal,
  },
  otpVerifyText: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: '800',
  },
  resendButton: {
    alignSelf: 'center',
    paddingVertical: 12,
    paddingHorizontal: 10,
  },
  resendText: {
    color: COLORS.teal,
    fontSize: 11,
    fontWeight: '800',
  },
  otpDemo: {
    marginTop: 2,
    padding: 9,
    borderRadius: 9,
    backgroundColor: '#FAF8FD',
  },
  otpDemoText: {
    color: COLORS.muted,
    fontSize: 10,
    lineHeight: 16,
    textAlign: 'center',
  },
  otpDemoStrong: {
    color: COLORS.teal,
    fontWeight: '900',
  },
  modalClose: {
    position: 'absolute',
    top: 10,
    right: 12,
    width: 36,
    height: 36,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
