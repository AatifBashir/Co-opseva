import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Animated,
  Easing,
  Image,
  Modal,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
  useWindowDimensions,
} from 'react-native';

/*
  CO-OPSEVA Panel / Role Selection
  Converted from: panel new1.html

  IMPORTANT:
  - Put your CO-OPSEVA logo at: ./assets/logo.png
  - This screen works with React Navigation, but also has safe fallbacks.
  - No Bootstrap, Bootstrap Icons or browser-only CSS/JS is required.
*/

const LOGO = require('../assets/logo.png');

const COLORS = {
  teal: '#6A5986',
  tealDark: '#55476E',
  navy: '#3D3350',
  accent: '#6A5986',
  bg: '#F8F5FB',
  white: '#FFFFFF',
  text: '#2B2238',
  muted: '#7A7189',
  border: '#E2D9EC',
  lightPurple: '#EDE7F5',
  cardPurple: '#5B4D78',
  cardPurpleDark: '#2A2138',
};

const ROLES = [
  {
    key: 'customer',
    number: '01',
    icon: '⌂',
    label: 'SERVICE SEEKER',
    title: 'Customer',
    button: 'Continue as Customer',
    badge: '★  Most popular',
    route: 'CustomerLogin',
    benefits: [
      'Book verified household services',
      'Track requests in real time',
      'Rate workers & build trust',
    ],
  },
  {
    key: 'worker',
    number: '02',
    icon: '⚒',
    label: 'SERVICE PROFESSIONAL',
    title: 'Worker',
    button: 'Continue as Worker',
    badge: '↗  Fair pay',
    route: 'WorkerLogin',
    benefits: [
      'Accept nearby job requests',
      'Get paid transparently',
      'Build your cooperative rating',
    ],
  },
  {
    key: 'society',
    number: '03',
    icon: '♟',
    label: 'LOCAL GOVERNANCE',
    title: 'Society Admin',
    button: 'Continue as Society Admin',
    badge: '✓  Admin access',
    route: 'SocietyLogin',
    benefits: [
      'Onboard & verify members',
      'Oversee local services',
      'Review society performance',
    ],
  },
  {
    key: 'federation',
    number: '04',
    icon: '▦',
    label: 'NETWORK GOVERNANCE',
    title: 'Federation Admin',
    button: 'Continue as Federation Admin',
    badge: '◇  Network-wide',
    route: 'FederationLogin',
    benefits: [
      'Monitor every society',
      'Set network-wide policy',
      'Analyze cooperative growth',
    ],
  },
];

const HELP_ITEMS = [
  ['⌂', 'Customer', 'Book household services.'],
  ['⚒', 'Worker', 'Find fair work opportunities.'],
  ['♟', 'Society Admin', 'Manage a local cooperative society.'],
  ['▦', 'Federation Admin', 'Oversee the cooperative network.'],
];

function Logo({ size = 80, style }) {
  return (
    <Image
      source={LOGO}
      resizeMode="contain"
      style={[{ width: size, height: size }, style]}
    />
  );
}

function BackgroundDecor({ width, height }) {
  const drift = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.loop(
      Animated.timing(drift, {
        toValue: 1,
        duration: 12000,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    ).start();
  }, [drift]);

  const translate = drift.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 42],
  });

  const dots = [
    { left: width * 0.07, top: height * 0.18, color: COLORS.teal },
    { left: width * 0.88, top: height * 0.31, color: COLORS.accent },
    { left: width * 0.13, top: height * 0.70, color: COLORS.teal },
    { left: width * 0.82, top: height * 0.82, color: COLORS.navy },
    { left: width * 0.70, top: height * 0.10, color: COLORS.teal },
  ];

  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      <Animated.View
        style={[
          styles.networkGrid,
          { transform: [{ translateX: translate }, { translateY: translate }] },
        ]}
      >
        {Array.from({ length: 110 }).map((_, i) => (
          <View key={i} style={styles.gridDot} />
        ))}
      </Animated.View>

      {dots.map((dot, i) => (
        <FloatingDot key={i} {...dot} delay={i * 450} />
      ))}

      <Animated.View
        style={[
          styles.bgLine,
          {
            width: 380,
            left: -130,
            top: height * 0.28,
            transform: [{ rotate: '-25deg' }, { translateX: translate }],
          },
        ]}
      />
      <Animated.View
        style={[
          styles.bgLine,
          {
            width: 380,
            right: -140,
            top: height * 0.68,
            transform: [{ rotate: '25deg' }, { translateX: translate }],
          },
        ]}
      />
      <Animated.View
        style={[
          styles.bgLine,
          {
            width: 280,
            right: width * 0.06,
            top: height * 0.14,
            transform: [{ rotate: '-40deg' }, { translateX: translate }],
          },
        ]}
      />
    </View>
  );
}

function FloatingDot({ left, top, color, delay = 0 }) {
  const y = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const timer = setTimeout(() => {
      Animated.loop(
        Animated.sequence([
          Animated.timing(y, {
            toValue: -16,
            duration: 3000,
            easing: Easing.inOut(Easing.ease),
            useNativeDriver: true,
          }),
          Animated.timing(y, {
            toValue: 0,
            duration: 3000,
            easing: Easing.inOut(Easing.ease),
            useNativeDriver: true,
          }),
        ])
      ).start();
    }, delay);

    return () => clearTimeout(timer);
  }, [delay, y]);

  return (
    <Animated.View
      style={[
        styles.floatingDot,
        {
          left,
          top,
          backgroundColor: color,
          transform: [{ translateY: y }],
        },
      ]}
    />
  );
}

function SplashScreen({ onFinished }) {
  const { width, height } = useWindowDimensions();
  const [visible, setVisible] = useState(true);

  const logoScale = useRef(new Animated.Value(0.65)).current;
  const logoOpacity = useRef(new Animated.Value(0)).current;
  const brandY = useRef(new Animated.Value(22)).current;
  const brandOpacity = useRef(new Animated.Value(0)).current;
  const tagY = useRef(new Animated.Value(14)).current;
  const tagOpacity = useRef(new Animated.Value(0)).current;
  const lineWidth = useRef(new Animated.Value(0)).current;
  const loadingOpacity = useRef(new Animated.Value(0)).current;
  const ringRotate = useRef(new Animated.Value(0)).current;

  const finish = () => {
    if (!visible) return;

    setVisible(false);

    setTimeout(() => {
      onFinished?.();
    }, 80);
  };

  useEffect(() => {
    Animated.sequence([
      Animated.parallel([
        Animated.timing(logoOpacity, {
          toValue: 1,
          duration: 350,
          useNativeDriver: true,
        }),
        Animated.spring(logoScale, {
          toValue: 1,
          friction: 6,
          tension: 55,
          useNativeDriver: true,
        }),
      ]),
      Animated.delay(850),
      Animated.parallel([
        Animated.timing(brandOpacity, {
          toValue: 1,
          duration: 650,
          easing: Easing.out(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(brandY, {
          toValue: 0,
          duration: 650,
          easing: Easing.out(Easing.ease),
          useNativeDriver: true,
        }),
      ]),
      Animated.parallel([
        Animated.timing(tagOpacity, {
          toValue: 1,
          duration: 650,
          useNativeDriver: true,
        }),
        Animated.timing(tagY, {
          toValue: 0,
          duration: 650,
          useNativeDriver: true,
        }),
      ]),
      Animated.timing(lineWidth, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
      }),
      Animated.timing(loadingOpacity, {
        toValue: 1,
        duration: 500,
        useNativeDriver: true,
      }),
    ]).start();

    Animated.loop(
      Animated.timing(ringRotate, {
        toValue: 1,
        duration: 5500,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    ).start();

    const timer = setTimeout(finish, 5000);

    return () => clearTimeout(timer);
  }, [
    brandOpacity,
    brandY,
    finish,
    lineWidth,
    loadingOpacity,
    logoOpacity,
    logoScale,
    ringRotate,
    tagOpacity,
    tagY,
  ]);

  if (!visible) return null;

  const ringRotation = ringRotate.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

  const logoSize = Math.min(width * 0.62, 360);

  return (
    <View style={styles.splash}>
      <BackgroundDecor width={width} height={height} />

      <View style={styles.splashContent}>
        <Animated.View
          style={[
            styles.logoWrapper,
            {
              width: logoSize,
              height: logoSize,
              opacity: logoOpacity,
              transform: [{ scale: logoScale }],
            },
          ]}
        >
          <View style={styles.logoAura} />
          <Animated.View
            style={[
              styles.logoOrbit,
              { transform: [{ rotate: ringRotation }] },
            ]}
          >
            <View style={[styles.orbitNode, styles.orbitTop]} />
            <View style={[styles.orbitNode, styles.orbitRight]} />
            <View style={[styles.orbitNode, styles.orbitBottom]} />
            <View style={[styles.orbitNode, styles.orbitLeft]} />
          </Animated.View>

          <View style={styles.logoRing} />
          <Logo size={logoSize * 0.72} style={styles.logoShadow} />
        </Animated.View>

        <Animated.View
          style={{
            opacity: brandOpacity,
            transform: [{ translateY: brandY }],
          }}
        >
          <Text style={styles.splashBrand}>
            <Text style={styles.brandCoop}>CO-</Text>
            <Text style={styles.brandSeva}>OPSEVA</Text>
          </Text>
        </Animated.View>

        <Animated.View
          style={[
            styles.taglineContainer,
            {
              opacity: tagOpacity,
              transform: [{ translateY: tagY }],
            },
          ]}
        >
          <Text style={styles.tagline}>
            GROWING OPPORTUNITIES. STRENGTHENING COMMUNITIES.
          </Text>
          <Animated.View
            style={[
              styles.taglineLine,
              {
                width: lineWidth.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0, Math.min(180, width * 0.55)],
                }),
              },
            ]}
          />
        </Animated.View>
      </View>

      <Animated.View style={[styles.loading, { opacity: loadingOpacity }]}>
        <Text style={styles.loadingText}>Preparing your cooperative space</Text>
        <Text style={styles.loadingDots}>•••</Text>
      </Animated.View>

      <Pressable style={styles.skipButton} onPress={finish}>
        <Text style={styles.skipText}>Skip</Text>
      </Pressable>
    </View>
  );
}

function RoleCard({ role, index, onContinue, processing }) {
  const { width } = useWindowDimensions();
  const isSmall = width <= 380;
  const isMobile = width <= 767;

  const reveal = useRef(new Animated.Value(0)).current;
  const hover = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const timer = setTimeout(() => {
      Animated.spring(reveal, {
        toValue: 1,
        friction: 8,
        tension: 55,
        useNativeDriver: true,
      }).start();
    }, 60 + index * 100);

    return () => clearTimeout(timer);
  }, [index, reveal]);

  const handlePressIn = () => {
    Animated.spring(hover, {
      toValue: 1,
      friction: 8,
      tension: 90,
      useNativeDriver: true,
    }).start();
  };

  const handlePressOut = () => {
    Animated.spring(hover, {
      toValue: 0,
      friction: 8,
      tension: 90,
      useNativeDriver: true,
    }).start();
  };

  const translateY = Animated.add(
    reveal.interpolate({
      inputRange: [0, 1],
      outputRange: [25, 0],
    }),
    hover.interpolate({
      inputRange: [0, 1],
      outputRange: [0, -8],
    })
  );

  const scale = hover.interpolate({
    inputRange: [0, 1],
    outputRange: [1, 1.02],
  });

  return (
    <Animated.View
      style={[
        styles.roleWrapper,
        {
          minHeight: isSmall ? 168 : isMobile ? 190 : 260,
          opacity: reveal,
          transform: [{ translateY }, { scale }],
        },
      ]}
    >
      <Pressable
        disabled={processing}
        onPress={() => onContinue(role)}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        style={styles.roleCardPressable}
        accessibilityRole="button"
        accessibilityLabel={role.button}
      >
        <View style={styles.roleCard}>
          <View style={styles.cardDecorationTop} />
          <View style={styles.cardDecorationBottom} />

          <View style={styles.cardTop}>
            <Text style={styles.roleNumber}>{role.number}</Text>
            <View style={styles.selectionCheck}>
              <Text style={styles.checkText}>✓</Text>
            </View>
          </View>

          <View
            style={[
              styles.roleIconWrap,
              isSmall && styles.roleIconWrapSmall,
              isMobile && !isSmall && styles.roleIconWrapMobile,
            ]}
          >
            <View style={styles.iconRing} />
            <View
              style={[
                styles.roleIcon,
                role.key === 'customer' && styles.customerIcon,
                (role.key === 'society' || role.key === 'federation') &&
                  styles.adminIcon,
                isSmall && styles.roleIconSmall,
              ]}
            >
              <Text
                style={[
                  styles.roleIconText,
                  isSmall && styles.roleIconTextSmall,
                ]}
              >
                {role.icon}
              </Text>
            </View>
          </View>

          <View style={styles.roleContent}>
            <Text style={styles.roleLabel}>{role.label}</Text>
            <Text
              style={[
                styles.roleTitle,
                isSmall && styles.roleTitleSmall,
              ]}
              numberOfLines={2}
            >
              {role.title}
            </Text>
          </View>

          <View
            style={[
              styles.roleBottom,
              isSmall && styles.roleBottomSmall,
              isMobile && !isSmall && styles.roleBottomMobile,
            ]}
          >
            <Text
              style={[
                styles.roleButtonText,
                isSmall && styles.roleButtonTextSmall,
              ]}
              numberOfLines={2}
            >
              {processing ? 'Opening...' : role.button}
            </Text>
            {processing ? (
              <ActivityIndicator size="small" color={COLORS.cardPurple} />
            ) : (
              <Text style={styles.roleArrow}>→</Text>
            )}
          </View>

          <View style={styles.mobileBenefitHint}>
            <Text style={styles.benefitHintText}>Tap to continue</Text>
          </View>
        </View>
      </Pressable>
    </Animated.View>
  );
}

function HelpModal({ visible, onClose }) {
  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.helpBox}>
          <Pressable
            onPress={onClose}
            style={styles.helpClose}
            accessibilityLabel="Close help"
          >
            <Text style={styles.helpCloseText}>×</Text>
          </Pressable>

          <View style={styles.helpIcon}>
            <Text style={styles.helpIconText}>ⓘ</Text>
          </View>

          <Text style={styles.helpTitle}>Choose your role</Text>
          <Text style={styles.helpDescription}>
            Select the option that best describes how you want to use CO-OPSEVA.
          </Text>

          <View style={styles.helpList}>
            {HELP_ITEMS.map(([icon, title, description]) => (
              <View key={title} style={styles.helpItem}>
                <View style={styles.helpItemIcon}>
                  <Text style={styles.helpItemIconText}>{icon}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.helpItemTitle}>{title}</Text>
                  <Text style={styles.helpItemText}>{description}</Text>
                </View>
              </View>
            ))}
          </View>
        </View>
      </View>
    </Modal>
  );
}

function NewsletterDemo() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);

  const subscribe = () => {
    const valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());

    if (!valid) {
      Alert.alert('Enter email', 'Please enter a valid email address.');
      return;
    }

    setSent(true);
    setEmail('');
  };

  return (
    <View style={styles.newsletter}>
      <Text style={styles.newsletterTitle}>Stay connected</Text>
      <Text style={styles.newsletterText}>
        Get cooperative platform updates and important announcements.
      </Text>

      <View style={styles.newsletterForm}>
        <TextInput
          value={email}
          onChangeText={(value) => {
            setEmail(value);
            setSent(false);
          }}
          placeholder="Your email"
          placeholderTextColor="#9A8FAE"
          keyboardType="email-address"
          autoCapitalize="none"
          style={styles.newsletterInput}
        />
        <Pressable onPress={subscribe} style={styles.newsletterButton}>
          <Text style={styles.newsletterButtonText}>→</Text>
        </Pressable>
      </View>

      {sent && (
        <Text style={styles.newsletterSuccess}>
          Thanks — we'll send updates to your email.
        </Text>
      )}
    </View>
  );
}

function Footer({ onNavigate }) {
  const footerLink = (label, route) => (
    <Pressable
      key={label}
      onPress={() => onNavigate?.(route)}
      style={styles.footerLink}
    >
      <Text style={styles.footerLinkArrow}>›</Text>
      <Text style={styles.footerLinkText}>{label}</Text>
    </Pressable>
  );

  return (
    <View style={styles.footer}>
      <View style={styles.footerTopLine} />

      <View style={styles.footerGrid}>
        <View style={styles.footerColumn}>
          <View style={styles.footerBrand}>
            <Logo size={38} />
            <Text style={styles.footerBrandText}>CO-OPSEVA</Text>
          </View>
          <Text style={styles.footerDescription}>
            A cooperative digital platform connecting people, workers and
            communities through fair opportunities.
          </Text>

          <View style={styles.socialRow}>
            {['f', 'in', '◎', '▶'].map((item) => (
              <Pressable key={item} style={styles.socialButton}>
                <Text style={styles.socialText}>{item}</Text>
              </Pressable>
            ))}
          </View>
        </View>

        <View style={styles.footerColumn}>
          <Text style={styles.footerHeading}>Platform</Text>
          {footerLink('Customer', 'CustomerLogin')}
          {footerLink('Worker', 'WorkerLogin')}
          {footerLink('Society Admin', 'SocietyLogin')}
          {footerLink('Federation Admin', 'FederationLogin')}
        </View>

        <View style={styles.footerColumn}>
          <Text style={styles.footerHeading}>Cooperative</Text>
          {footerLink('About CO-OPSEVA', 'About')}
          {footerLink('How it works', 'HowItWorks')}
          {footerLink('Safety & Trust', 'Safety')}
          {footerLink('Help Center', 'Help')}
        </View>

        <View style={styles.footerColumn}>
          <NewsletterDemo />
        </View>
      </View>

      <View style={styles.footerBottom}>
        <Text style={styles.footerCopy}>
          •  © 2026 CO-OPSEVA. Growing opportunities. Strengthening communities.
        </Text>
        <View style={styles.legalRow}>
          <Text style={styles.legalText}>Privacy</Text>
          <Text style={styles.legalText}>Terms</Text>
          <Text style={styles.legalText}>Accessibility</Text>
        </View>
      </View>
    </View>
  );
}

export default function PanelNew1({
  navigation,
  onNavigate,
  onRoleSelect,
  showSplash = true,
}) {
  const { width, height } = useWindowDimensions();
  const [splashVisible, setSplashVisible] = useState(showSplash);
  const [helpVisible, setHelpVisible] = useState(false);
  const [processingRole, setProcessingRole] = useState(null);
  const [showTopButton, setShowTopButton] = useState(false);

  const scrollRef = useRef(null);

  const isMobile = width <= 767;
  const isTablet = width > 767 && width <= 1199;

  const goToRole = (role) => {
    if (processingRole) return;

    setProcessingRole(role.key);

    const customHandler = onRoleSelect || onNavigate;

    if (customHandler) {
      setTimeout(() => {
        setProcessingRole(null);
        customHandler(role.key, role.route);
      }, 350);
      return;
    }

    setTimeout(() => {
      setProcessingRole(null);

      if (navigation?.navigate) {
        navigation.navigate(role.route);
      } else {
        Alert.alert(
          'Navigation',
          `${role.button} selected.\nConnect "${role.route}" in your navigator.`
        );
      }
    }, 350);
  };

  const handleFooterNavigate = (route) => {
    if (onNavigate) {
      onNavigate(route);
      return;
    }

    if (navigation?.navigate) {
      navigation.navigate(route);
      return;
    }

    if (route === 'Help') {
      setHelpVisible(true);
      return;
    }

    Alert.alert('Navigation', `Connect "${route}" in your navigator.`);
  };

  const handleScroll = (event) => {
    const y = event.nativeEvent.contentOffset.y;
    setShowTopButton(y > 480);
  };

  const backToTop = () => {
    scrollRef.current?.scrollTo({ y: 0, animated: true });
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar
        barStyle="dark-content"
        backgroundColor={COLORS.bg}
        translucent={false}
      />

      {splashVisible && (
        <View style={StyleSheet.absoluteFill}>
          <SplashScreen onFinished={() => setSplashVisible(false)} />
        </View>
      )}

      <ScrollView
        ref={scrollRef}
        style={styles.scroll}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
        onScroll={handleScroll}
        scrollEventThrottle={16}
      >
        <View style={styles.roleScreen}>
          <BackgroundDecor width={width} height={height * 1.25} />

          <View
            style={[
              styles.container,
              isMobile && styles.containerMobile,
              isTablet && styles.containerTablet,
            ]}
          >
            <View style={styles.topBar}>
              <Pressable
                onPress={() => {
                  if (onNavigate) {
                    onNavigate('Panel');
                  } else if (navigation?.navigate) {
                    navigation.navigate('Panel');
                  }
                }}
                style={styles.brandLogo}
              >
                <Logo size={44} />
                <Text style={styles.logoName}>
                  <Text style={styles.logoCo}>CO-</Text>
                  <Text style={styles.logoSeva}>OPSEVA</Text>
                </Text>
              </Pressable>

              <Pressable
                onPress={() => setHelpVisible(true)}
                style={styles.helpButton}
              >
                <Text style={styles.helpButtonIcon}>?</Text>
                {!isMobile && <Text style={styles.helpButtonText}>Help</Text>}
              </Pressable>
            </View>

            <View style={styles.roleHeader}>
              <View style={styles.welcomeBadge}>
                <View style={styles.pulseDot} />
                <Text style={styles.welcomeBadgeText}>
                  Cooperative Digital Platform
                </Text>
              </View>

              <View
                style={[
                  styles.welcomeLogoWrap,
                  isMobile && styles.welcomeLogoMobile,
                  width <= 420 && styles.welcomeLogoTiny,
                ]}
              >
                <Logo
                  size={
                    width <= 420
                      ? 44
                      : isMobile
                      ? 60
                      : Math.min(width * 0.1, 108)
                  }
                />
              </View>

              <Text
                style={[
                  styles.roleHeaderTitle,
                  isMobile && styles.roleHeaderTitleMobile,
                ]}
              >
                Welcome to <Text style={styles.roleHeaderAccent}>CO-OPSEVA</Text>
              </Text>

              <Text
                style={[
                  styles.roleHeaderSubtitle,
                  isMobile && styles.roleHeaderSubtitleMobile,
                ]}
              >
                Fair Jobs, Transparent Wages & Real Dignity
              </Text>
            </View>

            <View
              style={[
                styles.roleGrid,
                isMobile && styles.roleGridMobile,
                width <= 420 && styles.roleGridTiny,
              ]}
            >
              {ROLES.map((role, index) => (
                <RoleCard
                  key={role.key}
                  role={role}
                  index={index}
                  processing={processingRole === role.key}
                  onContinue={goToRole}
                />
              ))}
            </View>

            <View style={styles.trustStrip}>
              <View style={styles.trustItem}>
                <View style={styles.trustIcon}>
                  <Text style={styles.trustIconText}>✓</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.trustStrong}>Verified Network</Text>
                  <Text style={styles.trustSmall}>Trusted cooperative access</Text>
                </View>
              </View>

              <View style={styles.trustDivider} />

              <View style={styles.trustItem}>
                <View style={styles.trustIcon}>
                  <Text style={styles.trustIconText}>₹</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.trustStrong}>Fair & Transparent</Text>
                  <Text style={styles.trustSmall}>Clear work and wage visibility</Text>
                </View>
              </View>

              <View style={styles.trustDivider} />

              <View style={styles.trustItem}>
                <View style={styles.trustIcon}>
                  <Text style={styles.trustIconText}>⌘</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.trustStrong}>Community First</Text>
                  <Text style={styles.trustSmall}>Built around cooperation</Text>
                </View>
              </View>
            </View>

            <Footer onNavigate={handleFooterNavigate} />
          </View>
        </View>
      </ScrollView>

      {showTopButton && (
        <Pressable onPress={backToTop} style={styles.backToTop}>
          <Text style={styles.backToTopText}>↑</Text>
        </Pressable>
      )}

      <HelpModal
        visible={helpVisible}
        onClose={() => setHelpVisible(false)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.bg,
  },
  scroll: {
    flex: 1,
    backgroundColor: COLORS.bg,
  },
  content: {
    flexGrow: 1,
  },

  /* Splash */
  splash: {
    flex: 1,
    backgroundColor: COLORS.bg,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  splashContent: {
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 3,
    width: '100%',
    paddingHorizontal: 24,
  },
  logoWrapper: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  logoAura: {
    position: 'absolute',
    width: '68%',
    height: '68%',
    borderRadius: 999,
    backgroundColor: 'rgba(106,89,134,0.12)',
    shadowColor: COLORS.teal,
    shadowOpacity: 0.28,
    shadowRadius: 24,
    shadowOffset: { width: 0, height: 0 },
    elevation: 10,
  },
  logoRing: {
    position: 'absolute',
    width: '88%',
    height: '88%',
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(106,89,134,0.20)',
    borderStyle: Platform.OS === 'ios' ? 'dashed' : 'solid',
  },
  logoOrbit: {
    position: 'absolute',
    width: '96%',
    height: '96%',
    borderRadius: 999,
  },
  orbitNode: {
    position: 'absolute',
    width: 8,
    height: 8,
    borderRadius: 99,
  },
  orbitTop: {
    top: 0,
    left: '50%',
    marginLeft: -4,
    backgroundColor: COLORS.navy,
  },
  orbitRight: {
    right: 0,
    top: '50%',
    marginTop: -4,
    backgroundColor: COLORS.teal,
  },
  orbitBottom: {
    bottom: 0,
    left: '50%',
    marginLeft: -4,
    backgroundColor: COLORS.accent,
  },
  orbitLeft: {
    left: 0,
    top: '50%',
    marginTop: -4,
    backgroundColor: COLORS.navy,
  },
  logoShadow: {
    shadowColor: COLORS.navy,
    shadowOpacity: 0.16,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 8,
  },
  splashBrand: {
    marginTop: -8,
    fontSize: 54,
    lineHeight: 60,
    fontWeight: '900',
    letterSpacing: 1,
  },
  brandCoop: {
    color: COLORS.navy,
  },
  brandSeva: {
    color: COLORS.teal,
  },
  taglineContainer: {
    alignItems: 'center',
    marginTop: 14,
  },
  tagline: {
    color: COLORS.muted,
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 1.7,
    textAlign: 'center',
  },
  taglineLine: {
    height: 2,
    marginTop: 10,
    borderRadius: 99,
    backgroundColor: COLORS.accent,
  },
  loading: {
    position: 'absolute',
    bottom: 28,
    alignItems: 'center',
    zIndex: 4,
  },
  loadingText: {
    color: COLORS.muted,
    fontSize: 12,
  },
  loadingDots: {
    color: COLORS.teal,
    fontSize: 18,
    letterSpacing: 4,
    marginTop: -3,
  },
  skipButton: {
    position: 'absolute',
    right: 24,
    bottom: 24,
    paddingHorizontal: 15,
    paddingVertical: 9,
    borderWidth: 1,
    borderColor: 'rgba(100,116,139,0.20)',
    borderRadius: 50,
    backgroundColor: 'rgba(255,255,255,0.90)',
    zIndex: 5,
  },
  skipText: {
    color: COLORS.muted,
    fontSize: 12,
    fontWeight: '800',
  },

  /* Background decoration */
  networkGrid: {
    position: 'absolute',
    left: -42,
    top: -42,
    width: '115%',
    height: '115%',
    flexDirection: 'row',
    flexWrap: 'wrap',
    opacity: 0.30,
  },
  gridDot: {
    width: 42,
    height: 42,
    borderRightWidth: 1,
    borderBottomWidth: 1,
    borderColor: 'rgba(61,51,80,0.07)',
  },
  floatingDot: {
    position: 'absolute',
    width: 7,
    height: 7,
    borderRadius: 99,
    opacity: 0.28,
  },
  bgLine: {
    position: 'absolute',
    height: 1,
    backgroundColor: 'rgba(106,89,134,0.16)',
    opacity: 0.7,
  },

  /* Role screen */
  roleScreen: {
    flex: 1,
    minHeight: 900,
    backgroundColor: COLORS.bg,
    overflow: 'hidden',
  },
  container: {
    width: '92%',
    maxWidth: 1240,
    alignSelf: 'center',
    paddingTop: 32,
    paddingBottom: 0,
    zIndex: 2,
  },
  containerTablet: {
    width: '92%',
  },
  containerMobile: {
    width: '94%',
    paddingTop: 14,
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 48,
    zIndex: 5,
  },
  brandLogo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logoName: {
    fontSize: 19,
    fontWeight: '900',
    letterSpacing: 0.5,
    marginLeft: 10,
  },
  logoCo: {
    color: COLORS.navy,
  },
  logoSeva: {
    color: COLORS.teal,
  },
  helpButton: {
    minWidth: 42,
    height: 40,
    paddingHorizontal: 15,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 50,
    backgroundColor: 'rgba(255,255,255,0.90)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
  },
  helpButtonIcon: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: COLORS.lightPurple,
    color: COLORS.teal,
    textAlign: 'center',
    lineHeight: 20,
    fontSize: 13,
    fontWeight: '900',
  },
  helpButtonText: {
    color: COLORS.navy,
    fontSize: 12,
    fontWeight: '800',
  },
  roleHeader: {
    alignItems: 'center',
    marginBottom: 45,
    zIndex: 3,
  },
  welcomeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 13,
    paddingVertical: 7,
    borderRadius: 50,
    backgroundColor: COLORS.lightPurple,
    marginBottom: 16,
  },
  welcomeBadgeText: {
    color: COLORS.teal,
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 0.4,
  },
  pulseDot: {
    width: 7,
    height: 7,
    borderRadius: 99,
    backgroundColor: COLORS.teal,
  },
  welcomeLogoWrap: {
    width: 108,
    height: 108,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 18,
  },
  welcomeLogoMobile: {
    width: 60,
    height: 60,
    marginBottom: 10,
  },
  welcomeLogoTiny: {
    width: 44,
    height: 44,
    marginBottom: 8,
  },
  roleHeaderTitle: {
    color: COLORS.navy,
    fontSize: 48,
    lineHeight: 55,
    fontWeight: '900',
    letterSpacing: -1.5,
    textAlign: 'center',
    marginBottom: 10,
  },
  roleHeaderTitleMobile: {
    fontSize: 25,
    lineHeight: 31,
    letterSpacing: -0.8,
  },
  roleHeaderAccent: {
    color: COLORS.teal,
  },
  roleHeaderSubtitle: {
    color: COLORS.muted,
    fontSize: 16,
    lineHeight: 26,
    textAlign: 'center',
  },
  roleHeaderSubtitleMobile: {
    fontSize: 12,
    lineHeight: 18,
  },

  /* Cards */
  roleGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 22,
    zIndex: 3,
  },
  roleGridMobile: {
    width: '100%',
    maxWidth: 440,
    alignSelf: 'center',
    gap: 10,
  },
  roleGridTiny: {
    gap: 8,
  },
  roleWrapper: {
    width: '23.2%',
    position: 'relative',
  },
  roleCardPressable: {
    flex: 1,
  },
  roleCard: {
    flex: 1,
    minHeight: 260,
    padding: 16,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.16)',
    backgroundColor: COLORS.cardPurple,
    overflow: 'hidden',
    shadowColor: COLORS.navy,
    shadowOpacity: 0.22,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 12 },
    elevation: 7,
  },
  cardDecorationTop: {
    position: 'absolute',
    width: 180,
    height: 180,
    right: -75,
    top: -75,
    borderRadius: 100,
    backgroundColor: 'rgba(255,255,255,0.09)',
  },
  cardDecorationBottom: {
    position: 'absolute',
    width: 120,
    height: 120,
    left: -65,
    bottom: -65,
    borderRadius: 100,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  cardTop: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    zIndex: 2,
  },
  roleNumber: {
    color: 'rgba(255,255,255,0.68)',
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 1,
  },
  selectionCheck: {
    width: 28,
    height: 28,
    borderRadius: 99,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.22)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkText: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 12,
    fontWeight: '900',
  },
  roleIconWrap: {
    width: 70,
    height: 70,
    alignSelf: 'center',
    marginTop: 18,
    marginBottom: 14,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  roleIconWrapMobile: {
    width: 64,
    height: 64,
    marginTop: 10,
    marginBottom: 10,
  },
  roleIconWrapSmall: {
    width: 52,
    height: 52,
    marginTop: 6,
    marginBottom: 8,
  },
  iconRing: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    borderRadius: 99,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.28)',
  },
  roleIcon: {
    width: 46,
    height: 46,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.14)',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.16,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 8 },
    elevation: 4,
  },
  roleIconSmall: {
    width: 36,
    height: 36,
    borderRadius: 12,
  },
  customerIcon: {
    backgroundColor: 'rgba(255,255,255,0.18)',
  },
  adminIcon: {
    backgroundColor: 'rgba(255,255,255,0.18)',
  },
  roleIconText: {
    color: '#FFFFFF',
    fontSize: 21,
    fontWeight: '800',
  },
  roleIconTextSmall: {
    fontSize: 16,
  },
  roleContent: {
    alignItems: 'center',
    zIndex: 2,
  },
  roleLabel: {
    color: 'rgba(255,255,255,0.80)',
    fontSize: 9,
    fontWeight: '900',
    letterSpacing: 1.4,
    textAlign: 'center',
  },
  roleTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '900',
    marginTop: 5,
    textAlign: 'center',
  },
  roleTitleSmall: {
    fontSize: 14,
    marginTop: 2,
  },
  roleBottom: {
    minHeight: 36,
    alignSelf: 'center',
    marginTop: 'auto',
    paddingHorizontal: 13,
    paddingVertical: 8,
    borderRadius: 9,
    backgroundColor: COLORS.white,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    maxWidth: '95%',
    shadowColor: '#000',
    shadowOpacity: 0.16,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 3,
  },
  roleBottomMobile: {
    minHeight: 34,
    paddingHorizontal: 10,
    paddingVertical: 7,
    borderRadius: 8,
  },
  roleBottomSmall: {
    minHeight: 32,
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 8,
  },
  roleButtonText: {
    color: COLORS.cardPurple,
    fontSize: 11,
    fontWeight: '900',
    textAlign: 'center',
    flexShrink: 1,
  },
  roleButtonTextSmall: {
    fontSize: 9,
  },
  roleArrow: {
    color: COLORS.cardPurple,
    fontSize: 14,
    fontWeight: '900',
  },
  mobileBenefitHint: {
    alignItems: 'center',
    marginTop: 7,
  },
  benefitHintText: {
    color: 'rgba(255,255,255,0.46)',
    fontSize: 8,
    fontWeight: '700',
  },

  /* Trust strip */
  trustStrip: {
    marginTop: 38,
    paddingHorizontal: 20,
    paddingVertical: 17,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.86)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    gap: 20,
    shadowColor: COLORS.navy,
    shadowOpacity: 0.05,
    shadowRadius: 15,
    shadowOffset: { width: 0, height: 8 },
    elevation: 2,
  },
  trustItem: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    minWidth: 0,
  },
  trustIcon: {
    width: 38,
    height: 38,
    borderRadius: 11,
    backgroundColor: COLORS.lightPurple,
    alignItems: 'center',
    justifyContent: 'center',
  },
  trustIconText: {
    color: COLORS.teal,
    fontSize: 16,
    fontWeight: '900',
  },
  trustStrong: {
    color: COLORS.navy,
    fontSize: 11,
    fontWeight: '900',
  },
  trustSmall: {
    color: COLORS.muted,
    fontSize: 9,
    marginTop: 2,
  },
  trustDivider: {
    width: 1,
    height: 32,
    backgroundColor: COLORS.border,
  },

  /* Footer */
  footer: {
    marginTop: 60,
    paddingTop: 48,
    paddingHorizontal: 26,
    paddingBottom: 26,
    borderTopLeftRadius: 32,
    borderTopRightRadius: 32,
    borderWidth: 1,
    borderBottomWidth: 0,
    borderColor: 'rgba(220,231,236,0.90)',
    backgroundColor: 'rgba(255,255,255,0.90)',
    overflow: 'hidden',
  },
  footerTopLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 3,
    backgroundColor: COLORS.teal,
  },
  footerGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 34,
    paddingBottom: 34,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(220,231,236,0.90)',
  },
  footerColumn: {
    flex: 1,
    minWidth: 180,
  },
  footerBrand: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 14,
  },
  footerBrandText: {
    color: COLORS.navy,
    fontSize: 15,
    fontWeight: '900',
  },
  footerDescription: {
    color: COLORS.muted,
    fontSize: 11,
    lineHeight: 19,
    marginBottom: 18,
  },
  footerHeading: {
    color: COLORS.navy,
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 1.2,
    marginBottom: 14,
  },
  footerLink: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingVertical: 5,
  },
  footerLinkArrow: {
    color: COLORS.teal,
    fontSize: 14,
    fontWeight: '900',
  },
  footerLinkText: {
    color: COLORS.muted,
    fontSize: 11,
    fontWeight: '700',
  },
  socialRow: {
    flexDirection: 'row',
    gap: 10,
  },
  socialButton: {
    width: 36,
    height: 36,
    borderRadius: 99,
    borderWidth: 1,
    borderColor: COLORS.border,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  socialText: {
    color: COLORS.navy,
    fontSize: 11,
    fontWeight: '900',
  },
  newsletter: {
    width: '100%',
  },
  newsletterTitle: {
    color: COLORS.navy,
    fontSize: 12,
    fontWeight: '900',
    marginBottom: 8,
  },
  newsletterText: {
    color: COLORS.muted,
    fontSize: 10,
    lineHeight: 16,
    marginBottom: 10,
  },
  newsletterForm: {
    flexDirection: 'row',
    gap: 8,
  },
  newsletterInput: {
    flex: 1,
    minWidth: 0,
    height: 40,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 10,
    paddingHorizontal: 13,
    backgroundColor: '#FFFFFF',
    color: COLORS.text,
    fontSize: 11,
  },
  newsletterButton: {
    width: 42,
    height: 40,
    borderRadius: 10,
    backgroundColor: COLORS.teal,
    alignItems: 'center',
    justifyContent: 'center',
  },
  newsletterButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '900',
  },
  newsletterSuccess: {
    color: COLORS.teal,
    fontSize: 9,
    fontWeight: '800',
    marginTop: 7,
  },
  footerBottom: {
    paddingTop: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 16,
    flexWrap: 'wrap',
  },
  footerCopy: {
    color: '#9A8FAE',
    fontSize: 9,
    flexShrink: 1,
  },
  legalRow: {
    flexDirection: 'row',
    gap: 16,
    flexWrap: 'wrap',
  },
  legalText: {
    color: '#9A8FAE',
    fontSize: 9,
    fontWeight: '700',
  },

  /* Back to top */
  backToTop: {
    position: 'absolute',
    right: 24,
    bottom: 24,
    width: 46,
    height: 46,
    borderRadius: 99,
    backgroundColor: COLORS.navy,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: COLORS.navy,
    shadowOpacity: 0.30,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 8 },
    elevation: 8,
  },
  backToTopText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '900',
  },

  /* Help modal */
  modalOverlay: {
    flex: 1,
    padding: 20,
    backgroundColor: 'rgba(61,51,80,0.42)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  helpBox: {
    width: '100%',
    maxWidth: 480,
    maxHeight: '90%',
    borderRadius: 24,
    padding: 30,
    backgroundColor: '#FFFFFF',
    shadowColor: COLORS.navy,
    shadowOpacity: 0.22,
    shadowRadius: 35,
    shadowOffset: { width: 0, height: 18 },
    elevation: 15,
  },
  helpClose: {
    position: 'absolute',
    top: 15,
    right: 15,
    width: 34,
    height: 34,
    borderRadius: 99,
    backgroundColor: '#EFE9F6',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 5,
  },
  helpCloseText: {
    color: COLORS.muted,
    fontSize: 23,
    lineHeight: 25,
    fontWeight: '400',
  },
  helpIcon: {
    width: 56,
    height: 56,
    borderRadius: 16,
    backgroundColor: COLORS.lightPurple,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 15,
  },
  helpIconText: {
    color: COLORS.teal,
    fontSize: 25,
    fontWeight: '800',
  },
  helpTitle: {
    color: COLORS.navy,
    fontSize: 22,
    fontWeight: '900',
    marginBottom: 8,
  },
  helpDescription: {
    color: COLORS.muted,
    fontSize: 12,
    lineHeight: 19,
  },
  helpList: {
    marginTop: 18,
    gap: 9,
  },
  helpItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 11,
    padding: 11,
    borderRadius: 12,
    backgroundColor: COLORS.bg,
  },
  helpItemIcon: {
    width: 30,
    height: 30,
    borderRadius: 9,
    backgroundColor: COLORS.lightPurple,
    alignItems: 'center',
    justifyContent: 'center',
  },
  helpItemIconText: {
    color: COLORS.teal,
    fontSize: 15,
    fontWeight: '900',
  },
  helpItemTitle: {
    color: COLORS.navy,
    fontSize: 11,
    fontWeight: '900',
    marginBottom: 2,
  },
  helpItemText: {
    color: COLORS.muted,
    fontSize: 10,
    lineHeight: 15,
  },
});

export { COLORS, ROLES };
