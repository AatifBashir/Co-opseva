import React, { useState } from 'react';
import {
  Alert,
  Modal,
  Pressable,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';

const LOGO = require('../assets/logo.png');

const COLORS = {
  teal: '#7C6CA8',
  tealDark: '#5B4A8A',
  navy: '#3A2D59',
  bg: '#F3ECE0',
  white: '#FFFFFF',
  text: '#33284A',
  muted: '#736A8F',
  border: '#E4DDEF',
  lightPurple: '#EFEAF7',
  accent: '#7C6CA8',
};

const NAV_GROUPS = [
  {
    title: 'MAIN MENU',
    items: [
      ['dashboard', '▦', 'Dashboard'],
      ['jobs', '▣', 'My Jobs'],
      ['schedule', '□', 'Schedule'],
      ['route', '⌁', 'Daily Route'],
      ['earnings', '₹', 'Earnings Ledger'],
    ],
  },
  {
    title: 'GROWTH & SUPPORT',
    items: [
      ['opportunity', '◈', 'Opportunity Balance'],
      ['academy', '◆', 'Skill Academy'],
      ['certificate', '▤', 'Income Certificate'],
      ['safety', '✓', 'Safety & Welfare'],
    ],
  },
  {
    title: 'ACCOUNT',
    items: [
      ['profile', '●', 'Profile'],
      ['settings', '⚙', 'Settings'],
    ],
  },
];

const JOBS = [
  { icon: '⚡', title: 'Switchboard repair', detail: 'Aliganj • 10:30 AM • 2.1 km', amount: '₹450', status: 'Upcoming' },
  { icon: '◒', title: 'Cooler service', detail: 'Mahanagar • 12:15 PM • 1.4 km', amount: '₹550', status: 'Upcoming' },
  { icon: '⌂', title: 'Electrical inspection', detail: 'Indira Nagar • Completed 9:10 AM', amount: '₹500', status: 'Completed' },
  { icon: '⚒', title: 'Fan installation', detail: 'Gomti Nagar • Completed 8:00 AM', amount: '₹350', status: 'Completed' },
];

const ROUTE_STOPS = [
  ['09:10 AM — Indira Nagar', 'Electrical inspection • Completed'],
  ['10:30 AM — Aliganj', 'Switchboard repair • ₹450'],
  ['12:15 PM — Mahanagar', 'Cooler service • ₹550'],
  ['02:30 PM — Gomti Nagar', 'Fan installation • ₹350'],
];

export default function WorkerDashboard({
  navigation,
  userName = 'Ravi',
  initials = 'RK',
  onNavigate,
  onLogout,
}) {
  const { width } = useWindowDimensions();
  const isDesktop = width >= 992;
  const isTablet = width >= 768;

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [active, setActive] = useState('dashboard');
  const [online, setOnline] = useState(true);
  const [notifications, setNotifications] = useState(2);
  const [helpVisible, setHelpVisible] = useState(false);

  const contentPadding = width >= 1200 ? 34 : width >= 768 ? 20 : 14;

  const navigateTo = (key, label) => {
    setActive(key);
    setDrawerOpen(false);

    if (onNavigate) {
      onNavigate(key, label);
      return;
    }

    const routes = {
      dashboard: 'WorkerDashboard',
      jobs: 'WorkerJobs',
      schedule: 'WorkerSchedule',
      route: 'WorkerRoute',
      earnings: 'WorkerEarnings',
      opportunity: 'OpportunityBalance',
      academy: 'SkillAcademy',
      certificate: 'IncomeCertificate',
      safety: 'SafetyWelfare',
      profile: 'WorkerProfile',
      settings: 'WorkerSettings',
    };

    if (navigation?.navigate && routes[key]) {
      navigation.navigate(routes[key]);
    } else if (key !== 'dashboard') {
      Alert.alert(label, `${label} screen is ready to connect.`);
    }
  };

  const handleLogout = () => {
    setDrawerOpen(false);
    if (onLogout) {
      onLogout();
      return;
    }
    if (navigation?.navigate) navigation.navigate('WorkerLogin');
    else Alert.alert('Signed out', 'Worker session ended.');
  };

  return (
    <View style={styles.root}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.bg} />

      {isDesktop && (
        <Sidebar
          active={active}
          initials={initials}
          onSelect={navigateTo}
          onProfile={() => navigateTo('profile', 'Profile')}
          onLogout={handleLogout}
        />
      )}

      {!isDesktop && drawerOpen && (
        <Modal
          visible
          transparent
          animationType="none"
          onRequestClose={() => setDrawerOpen(false)}
        >
          <View style={styles.drawerOverlay}>
            <Pressable
              style={styles.drawerBackdrop}
              onPress={() => setDrawerOpen(false)}
            />
            <View style={styles.mobileDrawer}>
              <Sidebar
                active={active}
                initials={initials}
                mobile
                onSelect={navigateTo}
                onProfile={() => navigateTo('profile', 'Profile')}
                onLogout={handleLogout}
              />
            </View>
          </View>
        </Modal>
      )}

      <View style={styles.main}>
        <SafeAreaView style={styles.safeArea}>
          <View style={[styles.topbar, { paddingHorizontal: contentPadding }]}>
            <View style={styles.topLeft}>
              {!isDesktop && (
                <Pressable
                  onPress={() => setDrawerOpen(true)}
                  style={styles.iconButton}
                  accessibilityLabel="Open menu"
                >
                  <Text style={styles.iconText}>☰</Text>
                </Pressable>
              )}

              <View style={styles.pageTitle}>
                <Text style={[styles.pageTitleText, !isTablet && styles.mobileTitle]}>
                  Worker Dashboard
                </Text>
                {isTablet && (
                  <Text style={styles.pageSubtitle}>
                    Fair work. Transparent earnings. Stronger livelihood.
                  </Text>
                )}
              </View>
            </View>

            <View style={styles.topActions}>
              {isTablet && (
                <Pressable
                  onPress={() => setOnline(v => !v)}
                  style={[styles.onlinePill, !online && styles.offlinePill]}
                >
                  <View style={[styles.onlineDot, !online && styles.offlineDot]} />
                  <Text style={styles.onlineText}>
                    {online ? 'Available for work' : 'Offline'}
                  </Text>
                </Pressable>
              )}

              <Pressable
                onPress={() =>
                  Alert.alert('Voice Assistance', 'Voice assistance is ready to connect.')
                }
                style={styles.iconButton}
              >
                <Text style={styles.iconText}>●</Text>
              </Pressable>

              <Pressable
                onPress={() => {
                  setNotifications(0);
                  Alert.alert('Notifications', 'Your route and upcoming job notifications are up to date.');
                }}
                style={styles.iconButton}
              >
                <Text style={styles.iconText}>♢</Text>
                {notifications > 0 && (
                  <View style={styles.notificationBadge}>
                    <Text style={styles.notificationText}>{notifications}</Text>
                  </View>
                )}
              </Pressable>

              <Pressable
                onPress={() => navigateTo('profile', 'Profile')}
                style={styles.avatar}
              >
                <Text style={styles.avatarText}>{initials}</Text>
              </Pressable>
            </View>
          </View>

          <ScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={[
              styles.content,
              { paddingHorizontal: contentPadding },
            ]}
          >
            <WelcomeCard
              userName={userName}
              onRoute={() => navigateTo('route', "Today's Route")}
              onVoice={() =>
                Alert.alert('Voice Assistance', 'Voice assistance is ready to connect.')
              }
            />

            <SectionTitle
              title="Today's Overview"
              action="View detailed analytics"
              onAction={() =>
                Alert.alert('Analytics', 'Detailed worker analytics can be connected here.')
              }
            />

            <View style={styles.statGrid}>
              <StatCard icon="▣" label="JOBS TODAY" value="4" foot="2 completed • 2 upcoming" />
              <StatCard icon="₹" label="TODAY'S EARNINGS" value="₹1,850" foot="+12% vs. your average" />
              <StatCard icon="⌖" label="ROUTE SAVING" value="6.4 km" foot="Saved through route bundling" />
              <StatCard icon="✓" label="OPPORTUNITY BALANCE" value="78/100" foot="FairShare access score" />
            </View>

            <SectionTitle title="FairShare & Earnings" />

            <View style={isTablet ? styles.twoColumn : styles.oneColumn}>
              <View style={isTablet ? styles.fairColumn : styles.fullColumn}>
                <FairShareCard
                  onWhy={() =>
                    Alert.alert(
                      'Why this score?',
                      'Opportunity Balance considers skill, certification, availability, distance and fairness of access to work.'
                    )
                  }
                  onHistory={() =>
                    Alert.alert('Dispatch History', 'Your FairShare dispatch history can be connected here.')
                  }
                />
              </View>
              <View style={isTablet ? styles.earningsColumn : styles.fullColumn}>
                <EarningsLedger />
              </View>
            </View>

            <SectionTitle
              title="Today's Jobs"
              action="View all jobs"
              onAction={() => navigateTo('jobs', 'My Jobs')}
            />

            <View style={isTablet ? styles.twoColumn : styles.oneColumn}>
              <View style={isTablet ? styles.jobsColumn : styles.fullColumn}>
                <JobsPanel />
              </View>
              <View style={isTablet ? styles.routeColumn : styles.fullColumn}>
                <RouteCard
                  onMap={() => Alert.alert('Route Map', 'Map integration can be connected here.')}
                />
              </View>
            </View>

            <SectionTitle title="Worker Growth & Protection" />

            <View style={styles.actionGrid}>
              <ActionCard
                icon="▤"
                title="Income Certificate"
                description="Generate a cooperative-certified income statement from your verified payment ledger."
                action="Generate certificate"
                onPress={() => navigateTo('certificate', 'Income Certificate')}
              />
              <ActionCard
                icon="◆"
                title="Skill Academy"
                description="Complete regional-language training and fast-track certification recommended by demand forecasts."
                action="View recommended skills"
                onPress={() => navigateTo('academy', 'Skill Academy')}
              />
              <ActionCard
                icon="✓"
                title="Certification Freshness"
                description="Your electrician certification is valid. Renewal reminder will appear before the freshness score falls."
                action="View verification"
                onPress={() => navigateTo('profile', 'Verification')}
              />
            </View>

            <SectionTitle title="Protection & Alerts" />

            <View style={isTablet ? styles.twoColumn : styles.oneColumn}>
              <View style={isTablet ? styles.jobsColumn : styles.fullColumn}>
                <AlertCard
                  onExplore={() => navigateTo('academy', 'Skill Academy')}
                />
              </View>
              <View style={isTablet ? styles.routeColumn : styles.fullColumn}>
                <SOSCard
                  onView={() => navigateTo('safety', 'Safety & Welfare')}
                />
              </View>
            </View>

            <View style={styles.footer}>
              <Text style={styles.footerText}>© 2026 CO-OPSEVA • Worker Portal</Text>
              <Text style={styles.footerText}>
                Transparent work • Fair opportunity • Cooperative livelihood
              </Text>
            </View>

            <Pressable
              onPress={() => {
                if (navigation?.navigate) navigation.navigate('Panel');
                else if (navigation?.goBack) navigation.goBack();
              }}
              style={styles.backPanelButton}
            >
              <Text style={styles.backPanelText}>← Back to CO-OPSEVA</Text>
            </Pressable>
          </ScrollView>
        </SafeAreaView>
      </View>

      <Modal
        visible={helpVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setHelpVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <Pressable
            style={styles.modalBackdrop}
            onPress={() => setHelpVisible(false)}
          />
          <View style={styles.helpModal}>
            <Pressable
              onPress={() => setHelpVisible(false)}
              style={styles.closeButton}
            >
              <Text style={styles.closeText}>×</Text>
            </Pressable>

            <View style={styles.helpIconLarge}>
              <Text style={styles.helpIconText}>?</Text>
            </View>

            <Text style={styles.helpTitle}>Worker Dashboard</Text>
            <Text style={styles.helpDescription}>
              Manage jobs, routes, earnings, FairShare access and worker protection
              from one place.
            </Text>

            <HelpRow icon="▣" title="My Jobs" text="Review accepted and upcoming work." />
            <HelpRow icon="⌁" title="Daily Route" text="Follow your optimized job route." />
            <HelpRow icon="₹" title="Earnings" text="Check transparent verified payouts." />
            <HelpRow icon="✓" title="Protection" text="Access safety and welfare support." />
          </View>
        </View>
      </Modal>
    </View>
  );
}

function Sidebar({ active, initials, mobile, onSelect, onProfile, onLogout }) {
  return (
    <View style={[styles.sidebar, mobile && styles.mobileSidebar]}>
      <Pressable
        onPress={() => onSelect('dashboard', 'Dashboard')}
        style={styles.brand}
      >
        <View style={styles.logoMark}>
          <Text style={styles.logoMarkText}>⌘</Text>
        </View>
        <View>
          <Text style={styles.brandText}>
            <Text style={styles.brandCoop}>CO-OP</Text>
            <Text style={styles.brandSeva}>SEVA</Text>
          </Text>
          <Text style={styles.workerTag}>WORKER PORTAL</Text>
        </View>
      </Pressable>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.navScroll}>
        {NAV_GROUPS.map(group => (
          <View key={group.title}>
            <Text style={styles.navTitle}>{group.title}</Text>
            {group.items.map(([key, icon, label]) => (
              <Pressable
                key={key}
                onPress={() => onSelect(key, label)}
                style={[styles.sideLink, active === key && styles.sideLinkActive]}
              >
                <Text style={[styles.sideIcon, active === key && styles.sideIconActive]}>
                  {icon}
                </Text>
                <Text style={[styles.sideLinkText, active === key && styles.sideLinkTextActive]}>
                  {label}
                </Text>
              </Pressable>
            ))}
          </View>
        ))}

        {mobile && (
          <Pressable onPress={onLogout} style={styles.logoutLink}>
            <Text style={styles.logoutIcon}>↪</Text>
            <Text style={styles.logoutText}>Sign Out</Text>
          </Pressable>
        )}
      </ScrollView>

      <View style={styles.sidebarBottom}>
        <Pressable onPress={onProfile} style={styles.profileMini}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>{initials}</Text>
          </View>
          <View style={styles.profileMiniInfo}>
            <Text style={styles.profileName}>Ravi Kumar</Text>
            <Text style={styles.profileRole}>Electrician • Verified</Text>
          </View>
          <Text style={styles.chevron}>›</Text>
        </Pressable>

        {!mobile && (
          <Pressable onPress={onLogout} style={styles.desktopLogout}>
            <Text style={styles.logoutIcon}>↪</Text>
            <Text style={styles.logoutText}>Sign Out</Text>
          </Pressable>
        )}
      </View>
    </View>
  );
}

function WelcomeCard({ userName, onRoute, onVoice }) {
  return (
    <View style={styles.welcome}>
      <View style={styles.welcomeTop}>
        <View style={styles.welcomeCopy}>
          <Text style={styles.welcomeTitle}>
            Good morning, <Text style={styles.welcomeAccent}>{userName}!</Text>
          </Text>
          <Text style={styles.welcomeText}>
            You have 4 accepted jobs today. Your optimized route is ready.
          </Text>
        </View>
        <View style={styles.verifiedBadge}>
          <Text style={styles.verifiedText}>✓ Verified Worker</Text>
        </View>
      </View>

      <View style={styles.welcomeActions}>
        <Pressable onPress={onRoute} style={styles.primaryButton}>
          <Text style={styles.primaryButtonText}>⌁  View Today's Route</Text>
        </Pressable>
        <Pressable onPress={onVoice} style={styles.secondaryButton}>
          <Text style={styles.secondaryButtonText}>●  Voice Assistant</Text>
        </Pressable>
      </View>
    </View>
  );
}

function SectionTitle({ title, action, onAction }) {
  return (
    <View style={styles.sectionTitle}>
      <Text style={styles.sectionHeading}>{title}</Text>
      {action ? (
        <Pressable onPress={onAction}>
          <Text style={styles.sectionAction}>{action}  →</Text>
        </Pressable>
      ) : <View />}
    </View>
  );
}

function StatCard({ icon, label, value, foot }) {
  return (
    <View style={styles.statCard}>
      <View style={styles.statTop}>
        <View style={styles.statIcon}>
          <Text style={styles.statIconText}>{icon}</Text>
        </View>
        <Text style={styles.statTrend}>↗</Text>
      </View>
      <Text style={styles.statLabel}>{label}</Text>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statFoot}>{foot}</Text>
    </View>
  );
}

function FairShareCard({ onWhy, onHistory }) {
  return (
    <View style={styles.fairCard}>
      <Text style={styles.fairLabel}>FAIRSHARE DISPATCH™</Text>
      <Text style={styles.fairScore}>
        78<Text style={styles.fairScoreSmall}> / 100</Text>
      </Text>
      <Text style={styles.fairText}>
        Your Opportunity Balance considers skill, certification, availability,
        distance and fairness of access to work.
      </Text>

      <View style={styles.progressTrack}>
        <View style={styles.progressFill} />
      </View>

      <View style={styles.fairMeta}>
        <Text style={styles.fairMetaText}>Current balance</Text>
        <Text style={styles.fairMetaText}>Strong</Text>
      </View>

      <View style={styles.fairButtons}>
        <Pressable onPress={onWhy} style={styles.fairLightButton}>
          <Text style={styles.fairLightText}>Why this score?</Text>
        </Pressable>
        <Pressable onPress={onHistory} style={styles.fairOutlineButton}>
          <Text style={styles.fairOutlineText}>Dispatch history</Text>
        </Pressable>
      </View>
    </View>
  );
}

function EarningsLedger() {
  return (
    <View style={styles.panel}>
      <View style={styles.panelHead}>
        <Text style={styles.panelTitle}>Earnings Truth Ledger</Text>
        <Text style={styles.panelMeta}>✓ Tamper-evident</Text>
      </View>
      <LedgerRow label="Customer payment" value="₹600" />
      <LedgerRow label="Worker payout" value="₹510" />
      <LedgerRow label="Cooperative fund contribution" value="₹60" />
      <LedgerRow label="Welfare reserve" value="₹30" />

      <View style={styles.ledgerTotal}>
        <Text style={styles.ledgerTotalLabel}>Your verified earning</Text>
        <Text style={styles.ledgerTotalValue}>₹510</Text>
      </View>
    </View>
  );
}

function LedgerRow({ label, value }) {
  return (
    <View style={styles.ledgerRow}>
      <Text style={styles.ledgerLabel}>{label}</Text>
      <Text style={styles.ledgerValue}>{value}</Text>
    </View>
  );
}

function JobsPanel() {
  return (
    <View style={styles.panel}>
      <View style={styles.panelHead}>
        <Text style={styles.panelTitle}>Accepted & Upcoming</Text>
        <Text style={styles.panelMeta}>31 Aug 2026</Text>
      </View>

      {JOBS.map(job => (
        <View key={job.title} style={styles.job}>
          <View style={styles.jobIcon}>
            <Text style={styles.jobIconText}>{job.icon}</Text>
          </View>
          <View style={styles.jobInfo}>
            <Text style={styles.jobTitle}>{job.title}</Text>
            <Text style={styles.jobDetail}>{job.detail}</Text>
          </View>
          <View style={styles.jobRight}>
            <Text style={styles.jobAmount}>{job.amount}</Text>
            <View style={styles.statusBadge}>
              <Text style={styles.statusText}>{job.status}</Text>
            </View>
          </View>
        </View>
      ))}
    </View>
  );
}

function RouteCard({ onMap }) {
  return (
    <View style={styles.routeCard}>
      <View style={styles.routeHead}>
        <View style={styles.routeCopy}>
          <Text style={styles.routeTitle}>Daily Route Bundling</Text>
          <Text style={styles.routeSubtitle}>4 jobs • 8.7 km optimized route</Text>
        </View>
        <Pressable onPress={onMap} style={styles.routeButton}>
          <Text style={styles.routeButtonText}>⌖  Map</Text>
        </Pressable>
      </View>

      <View style={styles.routeLine}>
        {ROUTE_STOPS.map(([title, detail]) => (
          <View key={title} style={styles.stop}>
            <View style={styles.stopDot} />
            <Text style={styles.stopTitle}>{title}</Text>
            <Text style={styles.stopDetail}>{detail}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

function ActionCard({ icon, title, description, action, onPress }) {
  return (
    <View style={styles.actionCard}>
      <View style={styles.actionIcon}>
        <Text style={styles.actionIconText}>{icon}</Text>
      </View>
      <Text style={styles.actionTitle}>{title}</Text>
      <Text style={styles.actionDescription}>{description}</Text>
      <Pressable onPress={onPress}>
        <Text style={styles.actionLink}>{action}  →</Text>
      </Pressable>
    </View>
  );
}

function AlertCard({ onExplore }) {
  return (
    <View style={styles.alertCard}>
      <View style={styles.alertRow}>
        <View style={styles.alertIcon}>
          <Text style={styles.alertIconText}>✦</Text>
        </View>
        <View style={styles.alertCopy}>
          <Text style={styles.alertTitle}>Demand-based skill recommendation</Text>
          <Text style={styles.alertText}>
            AI demand forecasting predicts increased appliance-service demand
            in your area next month. Completing the recommended appliance-repair
            module could expand your eligible job pool.
          </Text>
          <Pressable onPress={onExplore} style={styles.alertButton}>
            <Text style={styles.alertButtonText}>Explore Skill Academy</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}

function SOSCard({ onView }) {
  return (
    <View style={styles.sosCard}>
      <View style={styles.sosIcon}>
        <Text style={styles.sosIconText}>!</Text>
      </View>
      <View style={styles.sosCopy}>
        <Text style={styles.sosTitle}>Cooperative SOS™</Text>
        <Text style={styles.sosText}>
          Urgent service response is available for eligible certified workers.
        </Text>
      </View>
      <Pressable onPress={onView} style={styles.sosButton}>
        <Text style={styles.sosButtonText}>View</Text>
      </Pressable>
    </View>
  );
}

function HelpRow({ icon, title, text }) {
  return (
    <View style={styles.helpRow}>
      <View style={styles.helpRowIcon}>
        <Text style={styles.helpRowIconText}>{icon}</Text>
      </View>
      <View style={styles.helpRowCopy}>
        <Text style={styles.helpRowTitle}>{title}</Text>
        <Text style={styles.helpRowText}>{text}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: COLORS.bg },
  safeArea: { flex: 1 },
  main: { flex: 1, minWidth: 0 },

  sidebar: {
    position: 'absolute',
    left: 0, top: 0, bottom: 0,
    width: 250,
    paddingTop: 24,
    paddingHorizontal: 16,
    backgroundColor: COLORS.white,
    borderRightWidth: 1,
    borderRightColor: COLORS.border,
    zIndex: 10,
  },
  mobileSidebar: {
    position: 'relative',
    width: '100%',
    height: '100%',
    borderRightWidth: 0,
  },
  brand: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingTop: 5,
    paddingBottom: 22,
  },
  logoMark: {
    width: 42, height: 42, borderRadius: 14,
    backgroundColor: COLORS.teal,
    alignItems: 'center', justifyContent: 'center',
    marginRight: 10,
    elevation: 4,
  },
  logoMarkText: { color: COLORS.white, fontSize: 20, fontWeight: '900' },
  brandText: { fontSize: 17, fontWeight: '900', letterSpacing: 0.4 },
  brandCoop: { color: COLORS.teal },
  brandSeva: { color: COLORS.tealDark },
  workerTag: {
    color: COLORS.teal, fontSize: 8, fontWeight: '900',
    letterSpacing: 1.2, marginTop: 2,
  },
  navScroll: { paddingBottom: 150 },
  navTitle: {
    color: COLORS.muted, fontSize: 9, fontWeight: '900',
    letterSpacing: 1.3, marginHorizontal: 12, marginTop: 15, marginBottom: 8,
  },
  sideLink: {
    minHeight: 44, flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 13, marginVertical: 2, borderRadius: 12,
  },
  sideLinkActive: {
    backgroundColor: COLORS.lightPurple,
    borderLeftWidth: 3, borderLeftColor: COLORS.teal, paddingLeft: 10,
  },
  sideIcon: {
    width: 25, textAlign: 'center', color: COLORS.muted,
    fontSize: 16, fontWeight: '800', marginRight: 8,
  },
  sideIconActive: { color: COLORS.teal },
  sideLinkText: { color: COLORS.muted, fontSize: 12, fontWeight: '700', flex: 1 },
  sideLinkTextActive: { color: COLORS.teal },
  sidebarBottom: {
    position: 'absolute', left: 16, right: 16, bottom: 18,
  },
  profileMini: {
    flexDirection: 'row', alignItems: 'center',
    padding: 11, borderWidth: 1, borderColor: COLORS.border,
    borderRadius: 15, backgroundColor: COLORS.white,
  },
  profileMiniInfo: { flex: 1, minWidth: 0, marginLeft: 10 },
  profileName: { color: COLORS.text, fontSize: 11, fontWeight: '900' },
  profileRole: { color: COLORS.muted, fontSize: 9, marginTop: 2 },
  chevron: { color: COLORS.muted, fontSize: 23, marginLeft: 5 },
  desktopLogout: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    marginTop: 9, paddingVertical: 9, borderRadius: 10,
  },
  logoutIcon: { color: COLORS.teal, fontSize: 15, marginRight: 8 },
  logoutText: { color: COLORS.teal, fontSize: 11, fontWeight: '800' },

  drawerOverlay: { flex: 1, flexDirection: 'row' },
  drawerBackdrop: { flex: 1, backgroundColor: 'rgba(51,40,74,0.35)' },
  mobileDrawer: { width: '82%', maxWidth: 330, backgroundColor: COLORS.white },

  topbar: {
    height: 74, backgroundColor: 'rgba(255,255,255,0.96)',
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
  },
  topLeft: { flexDirection: 'row', alignItems: 'center', flex: 1, minWidth: 0 },
  pageTitle: { minWidth: 0 },
  pageTitleText: { color: COLORS.teal, fontSize: 20, fontWeight: '900' },
  mobileTitle: { fontSize: 16 },
  pageSubtitle: { color: COLORS.muted, fontSize: 10, marginTop: 3 },
  topActions: { flexDirection: 'row', alignItems: 'center', marginLeft: 10 },
  onlinePill: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 12, paddingVertical: 8, borderRadius: 50,
    backgroundColor: COLORS.lightPurple, marginRight: 8,
  },
  offlinePill: { backgroundColor: '#F0ECEF' },
  onlineDot: {
    width: 7, height: 7, borderRadius: 4,
    backgroundColor: COLORS.teal, marginRight: 6,
  },
  offlineDot: { backgroundColor: COLORS.muted },
  onlineText: { color: COLORS.teal, fontSize: 9, fontWeight: '900' },
  iconButton: {
    width: 40, height: 40, borderWidth: 1, borderColor: COLORS.border,
    borderRadius: 12, backgroundColor: COLORS.white,
    alignItems: 'center', justifyContent: 'center', marginLeft: 7,
    position: 'relative',
  },
  iconText: { color: COLORS.teal, fontSize: 17, fontWeight: '900' },
  notificationBadge: {
    position: 'absolute', right: -2, top: -3,
    minWidth: 15, height: 15, borderRadius: 8,
    backgroundColor: COLORS.tealDark,
    alignItems: 'center', justifyContent: 'center', paddingHorizontal: 3,
  },
  notificationText: { color: COLORS.white, fontSize: 8, fontWeight: '900' },
  avatar: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: COLORS.lightPurple,
    alignItems: 'center', justifyContent: 'center', marginLeft: 8,
  },
  avatarText: { color: COLORS.teal, fontSize: 11, fontWeight: '900' },

  content: { paddingTop: 28, paddingBottom: 35 },
  welcome: {
    borderRadius: 22, padding: 26,
    backgroundColor: COLORS.white,
    borderWidth: 1, borderColor: COLORS.border,
    elevation: 2,
  },
  welcomeTop: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start',
  },
  welcomeCopy: { flex: 1, paddingRight: 10 },
  welcomeTitle: { color: COLORS.text, fontSize: 23, lineHeight: 29, fontWeight: '900' },
  welcomeAccent: { color: COLORS.teal },
  welcomeText: { color: COLORS.muted, fontSize: 11, lineHeight: 17, marginTop: 4 },
  verifiedBadge: {
    backgroundColor: COLORS.lightPurple, borderRadius: 50,
    paddingVertical: 7, paddingHorizontal: 10,
  },
  verifiedText: { color: COLORS.teal, fontSize: 8, fontWeight: '900' },
  welcomeActions: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 17 },
  primaryButton: {
    backgroundColor: COLORS.teal, borderRadius: 11,
    paddingVertical: 11, paddingHorizontal: 15, marginRight: 9, marginBottom: 5,
  },
  primaryButtonText: { color: COLORS.white, fontSize: 10, fontWeight: '900' },
  secondaryButton: {
    borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.white,
    borderRadius: 11, paddingVertical: 10, paddingHorizontal: 14, marginBottom: 5,
  },
  secondaryButtonText: { color: COLORS.text, fontSize: 10, fontWeight: '900' },

  sectionTitle: {
    minHeight: 30, flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between', marginTop: 28, marginBottom: 13,
  },
  sectionHeading: { color: COLORS.teal, fontSize: 14, fontWeight: '900' },
  sectionAction: { color: COLORS.teal, fontSize: 9, fontWeight: '900' },
  statGrid: { flexDirection: 'row', flexWrap: 'wrap', marginHorizontal: -5 },
  statCard: {
    flex: 1, minWidth: 145, marginHorizontal: 5, marginBottom: 10,
    backgroundColor: COLORS.white, borderWidth: 1, borderColor: COLORS.border,
    borderRadius: 18, padding: 18, elevation: 2,
  },
  statTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  statIcon: {
    width: 38, height: 38, borderRadius: 12,
    backgroundColor: COLORS.lightPurple, alignItems: 'center', justifyContent: 'center',
  },
  statIconText: { color: COLORS.teal, fontSize: 17, fontWeight: '900' },
  statTrend: { color: COLORS.teal, fontSize: 16, fontWeight: '900' },
  statLabel: { color: COLORS.muted, fontSize: 9, fontWeight: '800', marginTop: 13 },
  statValue: { color: COLORS.text, fontSize: 21, fontWeight: '900', marginTop: 3 },
  statFoot: { color: COLORS.muted, fontSize: 8, marginTop: 5, lineHeight: 13 },

  oneColumn: { width: '100%' },
  twoColumn: { width: '100%', flexDirection: 'row', marginHorizontal: -6 },
  fullColumn: { width: '100%', marginBottom: 12 },
  fairColumn: { flex: 0.85, marginHorizontal: 6 },
  earningsColumn: { flex: 1.15, marginHorizontal: 6 },
  jobsColumn: { flex: 1.15, marginHorizontal: 6 },
  routeColumn: { flex: 0.85, marginHorizontal: 6 },

  fairCard: {
    minHeight: 235, backgroundColor: COLORS.teal,
    borderRadius: 20, padding: 21, elevation: 4,
  },
  fairLabel: {
    color: COLORS.white, opacity: 0.88, fontSize: 9,
    letterSpacing: 1, fontWeight: '900',
  },
  fairScore: { color: COLORS.white, fontSize: 35, fontWeight: '900', marginVertical: 7 },
  fairScoreSmall: { fontSize: 12, opacity: 0.8 },
  fairText: {
    color: COLORS.white, opacity: 0.88, fontSize: 9,
    lineHeight: 14, marginBottom: 15,
  },
  progressTrack: {
    height: 7, borderRadius: 50,
    backgroundColor: 'rgba(255,255,255,0.25)', overflow: 'hidden',
  },
  progressFill: {
    height: '100%', width: '78%', backgroundColor: COLORS.white, borderRadius: 50,
  },
  fairMeta: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 9 },
  fairMetaText: { color: COLORS.white, opacity: 0.85, fontSize: 8, fontWeight: '700' },
  fairButtons: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 15 },
  fairLightButton: {
    backgroundColor: COLORS.white, borderRadius: 9,
    paddingVertical: 8, paddingHorizontal: 10, marginRight: 7, marginBottom: 5,
  },
  fairLightText: { color: COLORS.teal, fontSize: 8, fontWeight: '900' },
  fairOutlineButton: {
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.75)',
    borderRadius: 9, paddingVertical: 8, paddingHorizontal: 10, marginBottom: 5,
  },
  fairOutlineText: { color: COLORS.white, fontSize: 8, fontWeight: '900' },

  panel: {
    backgroundColor: COLORS.white, borderWidth: 1, borderColor: COLORS.border,
    borderRadius: 18, padding: 19, elevation: 2, minHeight: 100,
  },
  panelHead: {
    flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between', marginBottom: 10,
  },
  panelTitle: { color: COLORS.teal, fontSize: 12, fontWeight: '900' },
  panelMeta: { color: COLORS.muted, fontSize: 8 },
  ledgerRow: {
    flexDirection: 'row', justifyContent: 'space-between',
    paddingVertical: 9, borderBottomWidth: 1, borderBottomColor: COLORS.lightPurple,
  },
  ledgerLabel: { color: COLORS.muted, fontSize: 9, flex: 1 },
  ledgerValue: { color: COLORS.text, fontSize: 9, fontWeight: '900' },
  ledgerTotal: {
    flexDirection: 'row', justifyContent: 'space-between',
    backgroundColor: COLORS.lightPurple, borderRadius: 11,
    padding: 11, marginTop: 10,
  },
  ledgerTotalLabel: { color: COLORS.teal, fontSize: 9, fontWeight: '800' },
  ledgerTotalValue: { color: COLORS.teal, fontSize: 12, fontWeight: '900' },

  job: {
    flexDirection: 'row', alignItems: 'center',
    paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: COLORS.lightPurple,
  },
  jobIcon: {
    width: 38, height: 38, borderRadius: 11,
    backgroundColor: COLORS.lightPurple, alignItems: 'center',
    justifyContent: 'center', marginRight: 12,
  },
  jobIconText: { color: COLORS.teal, fontSize: 16, fontWeight: '900' },
  jobInfo: { flex: 1, minWidth: 0, paddingRight: 5 },
  jobTitle: { color: COLORS.text, fontSize: 10, fontWeight: '900' },
  jobDetail: { color: COLORS.muted, fontSize: 8, marginTop: 3 },
  jobRight: { alignItems: 'flex-end' },
  jobAmount: { color: COLORS.teal, fontSize: 10, fontWeight: '900', marginBottom: 4 },
  statusBadge: {
    backgroundColor: COLORS.lightPurple, borderRadius: 50,
    paddingVertical: 4, paddingHorizontal: 7,
  },
  statusText: { color: COLORS.teal, fontSize: 7, fontWeight: '900' },

  routeCard: {
    backgroundColor: COLORS.white, borderWidth: 1, borderColor: COLORS.border,
    borderRadius: 18, padding: 18, elevation: 2, minHeight: 100,
  },
  routeHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  routeCopy: { flex: 1, paddingRight: 6 },
  routeTitle: { color: COLORS.teal, fontSize: 12, fontWeight: '900' },
  routeSubtitle: { color: COLORS.muted, fontSize: 8, marginTop: 4 },
  routeButton: {
    backgroundColor: COLORS.lightPurple, borderRadius: 10,
    paddingVertical: 8, paddingHorizontal: 10,
  },
  routeButtonText: { color: COLORS.teal, fontSize: 8, fontWeight: '900' },
  routeLine: {
    marginTop: 18, marginLeft: 5, paddingLeft: 21,
    borderLeftWidth: 2, borderLeftColor: COLORS.border,
  },
  stop: { position: 'relative', paddingBottom: 15 },
  stopDot: {
    position: 'absolute', left: -28, top: 2,
    width: 11, height: 11, borderRadius: 6,
    backgroundColor: COLORS.teal, borderWidth: 3, borderColor: COLORS.lightPurple,
  },
  stopTitle: { color: COLORS.text, fontSize: 9, fontWeight: '900' },
  stopDetail: { color: COLORS.muted, fontSize: 8, marginTop: 2 },

  actionGrid: { flexDirection: 'row', flexWrap: 'wrap', marginHorizontal: -5 },
  actionCard: {
    flex: 1, minWidth: 220, marginHorizontal: 5, marginBottom: 10,
    borderWidth: 1, borderColor: COLORS.border, borderRadius: 17,
    padding: 16, backgroundColor: COLORS.white, elevation: 2,
  },
  actionIcon: {
    width: 39, height: 39, borderRadius: 12,
    backgroundColor: COLORS.lightPurple, alignItems: 'center',
    justifyContent: 'center', marginBottom: 12,
  },
  actionIconText: { color: COLORS.teal, fontSize: 17, fontWeight: '900' },
  actionTitle: { color: COLORS.teal, fontSize: 10, fontWeight: '900', marginBottom: 5 },
  actionDescription: { color: COLORS.muted, fontSize: 8, lineHeight: 13, marginBottom: 11 },
  actionLink: { color: COLORS.teal, fontSize: 8, fontWeight: '900' },

  alertCard: {
    backgroundColor: COLORS.lightPurple, borderWidth: 1,
    borderColor: COLORS.border, borderRadius: 18, padding: 17,
  },
  alertRow: { flexDirection: 'row' },
  alertIcon: {
    width: 39, height: 39, borderRadius: 12,
    backgroundColor: COLORS.white, alignItems: 'center',
    justifyContent: 'center', marginRight: 12,
  },
  alertIconText: { color: COLORS.teal, fontSize: 18, fontWeight: '900' },
  alertCopy: { flex: 1 },
  alertTitle: { color: COLORS.teal, fontSize: 10, fontWeight: '900', marginBottom: 5 },
  alertText: { color: COLORS.text, fontSize: 8, lineHeight: 13 },
  alertButton: {
    alignSelf: 'flex-start', backgroundColor: COLORS.teal,
    borderRadius: 10, paddingVertical: 9, paddingHorizontal: 12, marginTop: 9,
  },
  alertButtonText: { color: COLORS.white, fontSize: 8, fontWeight: '900' },

  sosCard: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: COLORS.white, borderWidth: 1,
    borderColor: COLORS.border, borderRadius: 14, padding: 13,
  },
  sosIcon: {
    width: 38, height: 38, borderRadius: 11,
    backgroundColor: COLORS.lightPurple, alignItems: 'center',
    justifyContent: 'center', marginRight: 12,
  },
  sosIconText: { color: COLORS.teal, fontSize: 18, fontWeight: '900' },
  sosCopy: { flex: 1, minWidth: 0 },
  sosTitle: { color: COLORS.text, fontSize: 9, fontWeight: '900' },
  sosText: { color: COLORS.muted, fontSize: 8, lineHeight: 12, marginTop: 2 },
  sosButton: {
    borderWidth: 1, borderColor: COLORS.teal,
    borderRadius: 9, paddingVertical: 7, paddingHorizontal: 10, marginLeft: 7,
  },
  sosButtonText: { color: COLORS.teal, fontSize: 8, fontWeight: '900' },

  footer: {
    marginTop: 28, paddingTop: 18, paddingBottom: 4,
    borderTopWidth: 1, borderTopColor: COLORS.border,
    flexDirection: 'row', justifyContent: 'space-between', flexWrap: 'wrap',
  },
  footerText: { color: COLORS.muted, fontSize: 8, marginRight: 12, marginBottom: 4 },
  backPanelButton: {
    alignSelf: 'center', marginTop: 12, paddingVertical: 8,
    paddingHorizontal: 14, borderRadius: 50,
    backgroundColor: COLORS.white, borderWidth: 1, borderColor: COLORS.border,
  },
  backPanelText: { color: COLORS.teal, fontSize: 9, fontWeight: '800' },

  modalOverlay: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 20 },
  modalBackdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(51,40,74,0.45)' },
  helpModal: {
    width: '100%', maxWidth: 420, backgroundColor: COLORS.white,
    borderRadius: 22, padding: 24, borderWidth: 1, borderColor: COLORS.border,
    elevation: 8,
  },
  closeButton: {
    position: 'absolute', top: 12, right: 12, width: 32, height: 32,
    borderRadius: 16, backgroundColor: COLORS.lightPurple,
    alignItems: 'center', justifyContent: 'center', zIndex: 2,
  },
  closeText: { color: COLORS.teal, fontSize: 23, lineHeight: 25 },
  helpIconLarge: {
    width: 48, height: 48, borderRadius: 16,
    backgroundColor: COLORS.lightPurple, alignItems: 'center',
    justifyContent: 'center', marginBottom: 12,
  },
  helpIconText: { color: COLORS.teal, fontSize: 21, fontWeight: '900' },
  helpTitle: { color: COLORS.text, fontSize: 18, fontWeight: '900' },
  helpDescription: { color: COLORS.muted, fontSize: 10, lineHeight: 15, marginTop: 5, marginBottom: 12 },
  helpRow: {
    flexDirection: 'row', alignItems: 'center',
    paddingVertical: 9, borderTopWidth: 1, borderTopColor: COLORS.lightPurple,
  },
  helpRowIcon: {
    width: 34, height: 34, borderRadius: 10,
    backgroundColor: COLORS.lightPurple, alignItems: 'center',
    justifyContent: 'center', marginRight: 10,
  },
  helpRowIconText: { color: COLORS.teal, fontSize: 15, fontWeight: '900' },
  helpRowCopy: { flex: 1 },
  helpRowTitle: { color: COLORS.text, fontSize: 10, fontWeight: '900' },
  helpRowText: { color: COLORS.muted, fontSize: 8, marginTop: 2 },
  logoutLink: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 13, paddingVertical: 12,
    marginTop: 12, borderRadius: 12, backgroundColor: COLORS.lightPurple,
  },
});
