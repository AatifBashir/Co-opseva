import React, { useRef, useState } from 'react';
import {
  ActivityIndicator, Alert, Dimensions, KeyboardAvoidingView, Modal,
  Platform, Pressable, SafeAreaView, ScrollView, StatusBar, StyleSheet,
  Text, TextInput, View,
} from 'react-native';
import { Image } from 'react-native';

const { width } = Dimensions.get('window');
const LOGO = require('../assets/logo.png');

const COLORS = {
  teal: '#7C6CA8',
  tealDark: '#5B4A8A',
  navy: '#3A2D59',
  bg: '#F3ECE0',
  white: '#FFFFFF',
  text: '#33284A',
  muted: '#736A8F',
  border: '#E4DDEF',
  lightPurple: '#EFEAF7',
  back: '#3A2D59',
  back2: '#2E2244',
  accent: '#7C6CA8',
};

const DEMO_OTP = '123456';

export default function WorkerLogin({ navigation, onLogin, onRegister, onBack }) {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [otpVisible, setOtpVisible] = useState(false);
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [otpStatus, setOtpStatus] = useState('Verification code required.');
  const [otpType, setOtpType] = useState('default');
  const [verifying, setVerifying] = useState(false);
  const [forgotVisible, setForgotVisible] = useState(false);
  const [forgotValue, setForgotValue] = useState('');
  const otpRefs = useRef([]);

  const goBack = () => {
    if (onBack) return onBack();
    if (navigation?.goBack) return navigation.goBack();
    navigation?.navigate?.('Panel');
  };

  const openRegister = () => {
    if (onRegister) return onRegister();
    navigation?.navigate?.('WorkerRegister');
  };

  const submitLogin = () => {
    if (!identifier.trim()) {
      Alert.alert('Required', 'Please enter your mobile number or email address.');
      return;
    }
    if (!password) {
      Alert.alert('Required', 'Please enter your password.');
      return;
    }

    setOtp(['', '', '', '', '', '']);
    setOtpStatus(`A verification code has been sent to ${identifier.trim()}`);
    setOtpType('default');
    setOtpVisible(true);

    setTimeout(() => otpRefs.current[0]?.focus(), 250);
  };

  const updateOtp = (value, index) => {
    const clean = value.replace(/\D/g, '').slice(-1);
    const next = [...otp];
    next[index] = clean;
    setOtp(next);
    if (clean && index < 5) otpRefs.current[index + 1]?.focus();
  };

  const handleOtpKeyPress = (event, index) => {
    if (event.nativeEvent.key === 'Backspace' && !otp[index] && index > 0) {
      otpRefs.current[index - 1]?.focus();
    }
  };

  const verifyOtp = () => {
    const enteredOtp = otp.join('');
    if (enteredOtp.length !== 6) {
      setOtpStatus('Please enter all 6 digits.');
      setOtpType('error');
      return;
    }
    if (enteredOtp !== DEMO_OTP) {
      setOtpStatus('Incorrect OTP. Please try again.');
      setOtpType('error');
      return;
    }

    setVerifying(true);
    setOtpStatus('Verifying your worker account...');
    setOtpType('success');

    setTimeout(() => {
      setVerifying(false);
      setOtpStatus('OTP verified successfully. Redirecting to your dashboard...');
      setOtpType('success');

      setTimeout(() => {
        setOtpVisible(false);
        if (onLogin) {
          onLogin({ identifier: identifier.trim(), remember });
        } else {
          navigation?.navigate?.('WorkerDashboard', { identifier: identifier.trim() });
        }
      }, 500);
    }, 700);
  };

  const cancelOtp = () => {
    if (verifying) return;
    setOtpVisible(false);
    setOtp(['', '', '', '', '', '']);
  };

  const resendOtp = () => {
    setOtp(['', '', '', '', '', '']);
    setOtpStatus('A new verification code has been sent.');
    setOtpType('success');
    setTimeout(() => otpRefs.current[0]?.focus(), 100);
  };

  const resetPassword = () => {
    if (!forgotValue.trim()) {
      Alert.alert('Required', 'Please enter your mobile number or email.');
      return;
    }
    setForgotVisible(false);
    Alert.alert(
      'Reset link sent',
      `If an account exists for ${forgotValue.trim()}, recovery instructions have been sent.`
    );
    setForgotValue('');
  };

  return (
    <SafeAreaView style={styles.root}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.bg} />

      <View style={styles.navbar}>
        <View style={styles.navInner}>
          <Pressable onPress={goBack} style={styles.logoButton}>
            <View style={styles.logoBox}>
              <Image source={LOGO} style={styles.logoImage} />
            </View>
            <Text style={styles.logoText}>
              <Text style={styles.logoCoop}>CO-OP</Text>
              <Text style={styles.logoSeva}>SEVA</Text>
            </Text>
          </Pressable>

          <Pressable onPress={goBack} style={styles.backButton}>
            <Text style={styles.backArrow}>‹</Text>
            <Text style={styles.backText}>Back to Role Selection</Text>
          </Pressable>
        </View>
      </View>

      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={[styles.loginCard, width <= 767 && styles.loginCardMobile]}>
            <View style={[styles.leftPanel, width <= 767 && styles.leftPanelMobile]}>
              <View style={styles.leftDecorCircle} />

              <View style={styles.roleIcon}>
                <Text style={styles.roleIconText}>⚒</Text>
              </View>

              <Text style={styles.leftEyebrow}>WORKER / SERVICE PROVIDER</Text>

              <Text style={styles.leftTitle}>
  Empowering your{'\n'}
  <Text style={styles.leftTitleAccent}>skilled profession.</Text>
</Text>

              <Text style={styles.leftDescription}>
                Access job opportunities, manage service bookings, and grow your
                earnings within the CO-OPSEVA network.
              </Text>

              <View style={styles.features}>
                <Feature icon="▣" text="Consistent work opportunities" />
                <Feature icon="₹" text="Direct & transparent earnings" />
                <Feature icon="★" text="Skill verification & trust badge" />
                <Feature icon="◷" text="Flexible schedule management" />
              </View>
            </View>

            <View style={[styles.formPanel, width <= 767 && styles.formPanelMobile]}>
              <View style={styles.formContent}>
                <View style={styles.roleBadge}>
                  <Text style={styles.roleBadgeIcon}>⚒</Text>
                  <Text style={styles.roleBadgeText}>WORKER</Text>
                </View>

                <Text style={styles.formTitle}>Welcome Back</Text>
                <Text style={styles.formDescription}>
                  Sign in to access your worker profile and manage active jobs.
                </Text>

                <View style={styles.field}>
                  <Text style={styles.label}>MOBILE OR EMAIL</Text>
                  <View style={styles.inputWrapper}>
                    <Text style={styles.inputIcon}>◉</Text>
                    <TextInput
                      value={identifier}
                      onChangeText={setIdentifier}
                      placeholder="Mobile number or email address"
                      placeholderTextColor={COLORS.muted}
                      autoCapitalize="none"
                      autoCorrect={false}
                      keyboardType="email-address"
                      style={styles.input}
                    />
                  </View>
                </View>

                <View style={styles.field}>
                  <Text style={styles.label}>PASSWORD</Text>
                  <View style={styles.inputWrapper}>
                    <Text style={styles.inputIcon}>▣</Text>
                    <TextInput
                      value={password}
                      onChangeText={setPassword}
                      placeholder="Enter your password"
                      placeholderTextColor={COLORS.muted}
                      secureTextEntry={!showPassword}
                      autoCapitalize="none"
                      autoCorrect={false}
                      style={[styles.input, styles.passwordInput]}
                      onSubmitEditing={submitLogin}
                    />
                    <Pressable
                      onPress={() => setShowPassword(v => !v)}
                      style={styles.passwordButton}
                    >
                      <Text style={styles.passwordIcon}>{showPassword ? '◉' : '◌'}</Text>
                    </Pressable>
                  </View>
                </View>

                <View style={styles.optionsRow}>
                  <Pressable onPress={() => setRemember(v => !v)} style={styles.rememberRow}>
                    <View style={[styles.checkbox, remember && styles.checkboxChecked]}>
                      {remember && <Text style={styles.checkboxTick}>✓</Text>}
                    </View>
                    <Text style={styles.rememberText}>Remember me</Text>
                  </Pressable>

                  <Pressable onPress={() => setForgotVisible(true)}>
                    <Text style={styles.forgotText}>Forgot password?</Text>
                  </Pressable>
                </View>

                <Pressable
                  onPress={submitLogin}
                  style={({ pressed }) => [
                    styles.loginButton,
                    pressed && styles.loginButtonPressed,
                  ]}
                >
                  <Text style={styles.loginButtonText}>Login as Worker</Text>
                  <Text style={styles.loginArrow}>→</Text>
                </Pressable>

                <View style={styles.divider}>
                  <View style={styles.dividerLine} />
                  <Text style={styles.dividerText}>SECURE COOPERATIVE ACCESS</Text>
                  <View style={styles.dividerLine} />
                </View>

                <View style={styles.registerTextRow}>
                  <Text style={styles.registerText}>Want to join as a Service Provider?</Text>
                  <Pressable onPress={openRegister}>
                    <Text style={styles.registerLink}> Register Here</Text>
                  </Pressable>
                </View>

                <View style={styles.securityBox}>
                  <Text style={styles.securityIcon}>◆</Text>
                  <Text style={styles.securityText}>
                    Your worker credentials and personal details are encrypted and securely verified.
                  </Text>
                </View>
              </View>
            </View>
          </View>

          <Text style={styles.footerText}>
            © CO-OPSEVA • Worker / Service Provider Access
          </Text>
        </ScrollView>
      </KeyboardAvoidingView>

      <Modal
        visible={otpVisible}
        transparent
        animationType="fade"
        onRequestClose={cancelOtp}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.otpCard}>
            <Pressable onPress={cancelOtp} disabled={verifying} style={styles.closeButton}>
              <Text style={styles.closeButtonText}>×</Text>
            </Pressable>

            <View style={styles.otpIcon}>
              <Text style={styles.otpIconText}>◆</Text>
            </View>

            <Text style={styles.otpTitle}>Verify Worker Login</Text>
            <Text style={styles.otpDescription}>
              Enter the 6-digit verification code sent to your registered mobile/email.
            </Text>

            <View style={styles.otpInputs}>
              {otp.map((digit, index) => (
                <TextInput
                  key={index}
                  ref={ref => { otpRefs.current[index] = ref; }}
                  value={digit}
                  onChangeText={value => updateOtp(value, index)}
                  onKeyPress={event => handleOtpKeyPress(event, index)}
                  keyboardType="number-pad"
                  maxLength={1}
                  selectTextOnFocus
                  style={[styles.otpInput, digit && styles.otpInputFilled]}
                />
              ))}
            </View>

            <Text
              style={[
                styles.otpStatus,
                otpType === 'error' && styles.otpStatusError,
                otpType === 'success' && styles.otpStatusSuccess,
              ]}
            >
              {otpStatus}
            </Text>

            <View style={styles.otpActions}>
              <Pressable
                onPress={cancelOtp}
                disabled={verifying}
                style={[styles.otpCancel, verifying && styles.disabledButton]}
              >
                <Text style={styles.otpCancelText}>Cancel</Text>
              </Pressable>

              <Pressable
                onPress={verifyOtp}
                disabled={verifying}
                style={[styles.otpVerify, verifying && styles.disabledButton]}
              >
                {verifying ? (
                  <ActivityIndicator size="small" color={COLORS.white} />
                ) : (
                  <Text style={styles.otpVerifyText}>Verify OTP</Text>
                )}
              </Pressable>
            </View>

            <Pressable onPress={resendOtp} disabled={verifying} style={styles.resendButton}>
              <Text style={styles.resendText}>Resend OTP</Text>
            </Pressable>

            <View style={styles.demoBox}>
              <Text style={styles.demoText}>
                Frontend demo OTP: <Text style={styles.demoOtp}>123456</Text>
                {'\n'}Replace this demo logic with your real OTP API/backend.
              </Text>
            </View>
          </View>
        </View>
      </Modal>

      <Modal
        visible={forgotVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setForgotVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.forgotCard}>
            <Pressable onPress={() => setForgotVisible(false)} style={styles.closeButton}>
              <Text style={styles.closeButtonText}>×</Text>
            </Pressable>

            <View style={styles.forgotIcon}>
              <Text style={styles.forgotIconText}>?</Text>
            </View>

            <Text style={styles.forgotTitle}>Reset Password</Text>
            <Text style={styles.forgotDescription}>
              Enter your registered mobile number or email address to receive recovery instructions.
            </Text>

            <TextInput
              value={forgotValue}
              onChangeText={setForgotValue}
              placeholder="Mobile number or email"
              placeholderTextColor={COLORS.muted}
              autoCapitalize="none"
              autoCorrect={false}
              style={styles.forgotInput}
            />

            <View style={styles.forgotActions}>
              <Pressable onPress={() => setForgotVisible(false)} style={styles.otpCancel}>
                <Text style={styles.otpCancelText}>Cancel</Text>
              </Pressable>
              <Pressable onPress={resetPassword} style={styles.otpVerify}>
                <Text style={styles.otpVerifyText}>Send Link</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

function Feature({ icon, text }) {
  return (
    <View style={styles.feature}>
      <View style={styles.featureIconBox}>
        <Text style={styles.featureIcon}>{icon}</Text>
      </View>
      <Text style={styles.featureText}>{text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: COLORS.bg },
  flex: { flex: 1 },

  navbar: {
    minHeight: 72,
    backgroundColor: 'rgba(255,255,255,0.96)',
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    justifyContent: 'center',
  },
  navInner: {
    width: '100%',
    maxWidth: 1180,
    alignSelf: 'center',
    paddingHorizontal: width > 767 ? 30 : 18,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  logoButton: { flexDirection: 'row', alignItems: 'center' },
  logoBox: {
    width: width <= 480 ? 38 : 42,
    height: width <= 480 ? 38 : 42,
    borderRadius: 12,
    padding: 4,
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.border,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  logoImage: { width: '100%', height: '100%', resizeMode: 'contain' },
  logoText: { fontSize: width <= 480 ? 18 : 21, fontWeight: '900' },
  logoCoop: { color: COLORS.text },
  logoSeva: { color: COLORS.teal },
  backButton: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8 },
  backArrow: { color: COLORS.muted, fontSize: 25, lineHeight: 24, marginRight: 4 },
  backText: { color: COLORS.muted, fontSize: width <= 480 ? 11 : 13, fontWeight: '700' },

  scrollContent: {
    flexGrow: 1,
    paddingVertical: width > 767 ? 42 : 22,
    paddingHorizontal: width > 767 ? 24 : 14,
    justifyContent: 'center',
  },

  loginCard: {
    width: '100%',
    maxWidth: 1120,
    minHeight: 620,
    alignSelf: 'center',
    backgroundColor: 'rgba(255,255,255,0.97)',
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 28,
    overflow: 'hidden',
    flexDirection: 'row',
    shadowColor: COLORS.navy,
    shadowOpacity: 0.10,
    shadowRadius: 30,
    shadowOffset: { width: 0, height: 16 },
    elevation: 7,
  },
  loginCardMobile: { flexDirection: 'column', minHeight: 0, borderRadius: 20 },

  leftPanel: {
    width: '50%',
    minHeight: 620,
    paddingHorizontal: 54,
    paddingVertical: 52,
    backgroundColor: COLORS.teal,
    justifyContent: 'center',
    overflow: 'hidden',
    position: 'relative',
  },
  leftPanelMobile: {
    width: '100%',
    minHeight: 0,
    paddingHorizontal: 24,
    paddingVertical: 34,
  },
  leftDecorCircle: {
    position: 'absolute',
    width: 360,
    height: 360,
    borderRadius: 180,
    right: -185,
    bottom: -185,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
  },
  roleIcon: {
    width: 100,
    height: 100,
    borderRadius: 28,
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.26)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 26,
  },
  roleIconText: { color: COLORS.white, fontSize: 43 },
  leftEyebrow: {
    color: 'rgba(255,255,255,0.92)',
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 0.5,
    marginBottom: 12,
  },
  leftTitle: {
    color: COLORS.white,
    fontSize: width > 1000 ? 42 : width > 767 ? 36 : 31,
    lineHeight: width > 1000 ? 47 : width > 767 ? 41 : 36,
    fontWeight: '900',
  },
  leftTitleAccent: { color: '#D5CAE3' },
  leftDescription: {
    maxWidth: 450,
    color: 'rgba(255,255,255,0.82)',
    fontSize: 14,
    lineHeight: 24,
    marginTop: 17,
  },
  features: { marginTop: 25 },
  feature: {
    width: '100%',
    minHeight: 42,
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 7,
    paddingHorizontal: 8,
    borderRadius: 12,
  },
  featureIconBox: {
    width: 30, height: 30, borderRadius: 9,
    backgroundColor: 'rgba(255,255,255,0.12)',
    alignItems: 'center', justifyContent: 'center', marginRight: 10,
  },
  featureIcon: { color: '#D5CAE3', fontSize: 15, fontWeight: '900' },
  featureText: { flex: 1, color: 'rgba(255,255,255,0.92)', fontSize: 12, fontWeight: '600' },

  formPanel: {
    width: '50%',
    minHeight: 620,
    paddingHorizontal: 54,
    paddingVertical: 52,
    justifyContent: 'center',
  },
  formPanelMobile: { width: '100%', minHeight: 0, paddingHorizontal: 24, paddingVertical: 34 },
  formContent: { width: '100%', maxWidth: 470, alignSelf: 'center' },

  roleBadge: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.lightPurple,
    borderRadius: 50,
    paddingVertical: 7,
    paddingHorizontal: 12,
  },
  roleBadgeIcon: { color: COLORS.teal, fontSize: 13, marginRight: 6 },
  roleBadgeText: { color: COLORS.teal, fontSize: 10, fontWeight: '900', letterSpacing: 1 },
  formTitle: {
    color: COLORS.text,
    fontSize: width > 767 ? 32 : 28,
    fontWeight: '900',
    marginTop: 18,
  },
  formDescription: {
    color: COLORS.muted,
    fontSize: 13,
    lineHeight: 22,
    marginTop: 7,
    marginBottom: 24,
  },
  field: { marginBottom: 16 },
  label: { color: COLORS.text, fontSize: 11, fontWeight: '800', marginBottom: 7 },
  inputWrapper: {
    minHeight: 52,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
    backgroundColor: '#FAFAFA',
    flexDirection: 'row',
    alignItems: 'center',
  },
  inputIcon: { width: 42, textAlign: 'center', color: COLORS.teal, fontSize: 16, fontWeight: '800' },
  input: { flex: 1, minHeight: 50, color: COLORS.text, fontSize: 13, paddingVertical: 0, paddingRight: 12 },
  passwordInput: { paddingRight: 48 },
  passwordButton: {
    width: 43, height: 43, position: 'absolute', right: 5, top: 4,
    borderRadius: 9, alignItems: 'center', justifyContent: 'center',
  },
  passwordIcon: { color: COLORS.muted, fontSize: 18, fontWeight: '800' },

  optionsRow: {
    minHeight: 30, flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between', marginBottom: 18,
  },
  rememberRow: { flexDirection: 'row', alignItems: 'center' },
  checkbox: {
    width: 18, height: 18, borderRadius: 5, borderWidth: 1,
    borderColor: COLORS.border, backgroundColor: COLORS.white,
    alignItems: 'center', justifyContent: 'center', marginRight: 7,
  },
  checkboxChecked: { backgroundColor: COLORS.teal, borderColor: COLORS.teal },
  checkboxTick: { color: COLORS.white, fontSize: 12, fontWeight: '900' },
  rememberText: { color: COLORS.muted, fontSize: 11 },
  forgotText: { color: COLORS.teal, fontSize: 11, fontWeight: '800' },

  loginButton: {
    width: '100%', minHeight: 54, borderRadius: 12,
    backgroundColor: COLORS.teal, flexDirection: 'row',
    alignItems: 'center', justifyContent: 'center',
    shadowColor: COLORS.teal, shadowOpacity: 0.25,
    shadowRadius: 13, shadowOffset: { width: 0, height: 7 }, elevation: 4,
  },
  loginButtonPressed: { backgroundColor: COLORS.tealDark, transform: [{ translateY: 1 }] },
  loginButtonText: { color: COLORS.white, fontSize: 13, fontWeight: '800' },
  loginArrow: { color: COLORS.white, fontSize: 18, fontWeight: '800', marginLeft: 8 },

  divider: { flexDirection: 'row', alignItems: 'center', marginVertical: 24 },
  dividerLine: { flex: 1, height: 1, backgroundColor: COLORS.border },
  dividerText: { color: COLORS.muted, fontSize: 8, fontWeight: '800', marginHorizontal: 9 },
  registerTextRow: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center' },
  registerText: { color: COLORS.muted, fontSize: 12 },
  registerLink: { color: COLORS.teal, fontSize: 12, fontWeight: '800' },
  securityBox: {
    marginTop: 20, padding: 12, borderRadius: 12,
    backgroundColor: COLORS.bg, flexDirection: 'row', alignItems: 'flex-start',
  },
  securityIcon: { color: COLORS.teal, fontSize: 15, marginRight: 9 },
  securityText: { flex: 1, color: COLORS.muted, fontSize: 10, lineHeight: 16 },
  footerText: { color: COLORS.muted, textAlign: 'center', fontSize: 9, marginTop: 18 },

  modalOverlay: {
    flex: 1, backgroundColor: 'rgba(45,37,58,0.62)',
    alignItems: 'center', justifyContent: 'center', paddingHorizontal: 18,
  },
  otpCard: {
    width: '100%', maxWidth: 440, backgroundColor: COLORS.white,
    borderRadius: 24, borderWidth: 1, borderColor: COLORS.border,
    paddingHorizontal: 28, paddingVertical: 30, elevation: 10,
  },
  closeButton: {
    position: 'absolute', right: 12, top: 10, width: 35, height: 35,
    borderRadius: 18, alignItems: 'center', justifyContent: 'center', zIndex: 5,
  },
  closeButtonText: { color: COLORS.muted, fontSize: 27, lineHeight: 27 },
  otpIcon: {
    width: 62, height: 62, borderRadius: 18, backgroundColor: COLORS.teal,
    alignSelf: 'center', alignItems: 'center', justifyContent: 'center', marginBottom: 15,
  },
  otpIconText: { color: COLORS.white, fontSize: 24 },
  otpTitle: { color: COLORS.text, textAlign: 'center', fontSize: 22, fontWeight: '900' },
  otpDescription: { color: COLORS.muted, textAlign: 'center', fontSize: 12, lineHeight: 19, marginTop: 6 },
  otpInputs: { flexDirection: 'row', justifyContent: 'center', marginTop: 20, marginBottom: 12 },
  otpInput: {
    width: width <= 480 ? 40 : 46, height: width <= 480 ? 48 : 52,
    borderWidth: 1, borderColor: COLORS.border, borderRadius: 10,
    color: COLORS.text, fontSize: 20, fontWeight: '800', textAlign: 'center',
    marginHorizontal: width <= 480 ? 3 : 4,
  },
  otpInputFilled: { borderColor: COLORS.teal, backgroundColor: COLORS.lightPurple },
  otpStatus: { minHeight: 38, color: '#B45309', textAlign: 'center', fontSize: 11, lineHeight: 17 },
  otpStatusError: { color: '#B91C1C' },
  otpStatusSuccess: { color: COLORS.teal },
  otpActions: { flexDirection: 'row', marginTop: 5 },
  otpCancel: {
    flex: 1, minHeight: 45, borderRadius: 11, borderWidth: 1,
    borderColor: COLORS.border, backgroundColor: COLORS.white,
    alignItems: 'center', justifyContent: 'center', marginRight: 5,
  },
  otpCancelText: { color: COLORS.muted, fontSize: 12, fontWeight: '800' },
  otpVerify: {
    flex: 1, minHeight: 45, borderRadius: 11, backgroundColor: COLORS.teal,
    alignItems: 'center', justifyContent: 'center', marginLeft: 5,
  },
  otpVerifyText: { color: COLORS.white, fontSize: 12, fontWeight: '800' },
  disabledButton: { opacity: 0.65 },
  resendButton: { alignSelf: 'center', marginTop: 15, padding: 5 },
  resendText: { color: COLORS.teal, fontSize: 11, fontWeight: '800' },
  demoBox: { marginTop: 13, padding: 9, borderRadius: 9, backgroundColor: COLORS.bg },
  demoText: { color: COLORS.muted, fontSize: 10, lineHeight: 16, textAlign: 'center' },
  demoOtp: { color: COLORS.teal, fontWeight: '900' },

  forgotCard: {
    width: '100%', maxWidth: 430, backgroundColor: COLORS.white,
    borderRadius: 22, borderWidth: 1, borderColor: COLORS.border, padding: 26, elevation: 10,
  },
  forgotIcon: {
    width: 58, height: 58, borderRadius: 17, alignSelf: 'center',
    backgroundColor: COLORS.lightPurple, alignItems: 'center', justifyContent: 'center', marginBottom: 14,
  },
  forgotIconText: { color: COLORS.teal, fontSize: 25, fontWeight: '900' },
  forgotTitle: { color: COLORS.text, textAlign: 'center', fontSize: 21, fontWeight: '900' },
  forgotDescription: { color: COLORS.muted, textAlign: 'center', fontSize: 12, lineHeight: 18, marginTop: 7, marginBottom: 18 },
  forgotInput: {
    height: 50, borderWidth: 1, borderColor: COLORS.border,
    borderRadius: 11, paddingHorizontal: 14, color: COLORS.text,
    fontSize: 13, backgroundColor: '#FAFAFA',
  },
  forgotActions: { flexDirection: 'row', marginTop: 16 },
});
