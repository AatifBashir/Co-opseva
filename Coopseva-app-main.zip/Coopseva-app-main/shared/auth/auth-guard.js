// shared/auth/auth-guard.js

export const authState = {
  user: null,
  role: null,

  login(role, user) {
    this.role = role;
    this.user = user;
  },

  logout() {
    this.role = null;
    this.user = null;
  }
};