// shared/state/store.js

export const store = {
  jobs: [
    {
      id: 'JOB-101',
      customerName: 'Sanjay Verma',
      trade: 'Electrician',
      problem: 'Switchboard sparking',
      amount: '₹450',
      status: 'Upcoming'
    },
    {
      id: 'JOB-102',
      customerName: 'Priya Awasthi',
      trade: 'Plumber',
      problem: 'Tap leaking in bathroom',
      amount: '₹350',
      status: 'Upcoming'
    }
  ],

  rateVotes: [
    { id: '1', trade: 'Electrician', rate: 350, votesFor: 18, votesAgainst: 4 },
    { id: '2', trade: 'Plumber', rate: 280, votesFor: 12, votesAgainst: 8 }
  ],

  // Simple function to add a job
  addJob(newJob) {
    this.jobs.unshift({
      id: 'JOB-' + Math.floor(100 + Math.random() * 900),
      status: 'Upcoming',
      ...newJob
    });
  }
};