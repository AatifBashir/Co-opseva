// shared/styles/theme.js

export const COLORS = {
  teal: '#7C6CA8',
  tealDark: '#5B4A8A',
  navy: '#3A2D59',
  bg: '#F3ECE0',
  white: '#FFFFFF',
  text: '#33284A',
  muted: '#736A8F',
  border: '#E4DDEF',
  lightPurple: '#EFEAF7',
  accent: '#7C6CA8',
};